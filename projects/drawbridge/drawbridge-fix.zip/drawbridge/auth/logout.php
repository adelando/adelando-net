<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_logout();
header('Location: ../auth/login.php');
exit;
