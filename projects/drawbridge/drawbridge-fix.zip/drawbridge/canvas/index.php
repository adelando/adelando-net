<?php
// DrawBridge Canvas - Main Whiteboard
// PHP logic MUST run before any HTML output
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_login();
$user = dbc_current_user();
$db   = dbc_get_db();

// Get or create personal canvas
$stmt = $db->prepare("SELECT * FROM dbc_canvases WHERE owner_id = ? AND type = 'personal' ORDER BY id ASC LIMIT 1");
$stmt->execute([$user['id']]);
$canvas = $stmt->fetch();

if (!$canvas) {
    $stmt = $db->prepare("INSERT INTO dbc_canvases (owner_id, name, type) VALUES (?, 'My Canvas', 'personal')");
    $stmt->execute([$user['id']]);
    $canvas_id = $db->lastInsertId();
    $stmt = $db->prepare("SELECT * FROM dbc_canvases WHERE id = ?");
    $stmt->execute([$canvas_id]);
    $canvas = $stmt->fetch();
}

// Get all canvases user has access to
$stmt = $db->prepare("
    SELECT c.*, u.username as owner_name, 'owner' as access_role
    FROM dbc_canvases c
    JOIN dbc_users u ON u.id = c.owner_id
    WHERE c.owner_id = ? AND c.is_active = 1
    UNION
    SELECT c.*, u.username as owner_name, cm.role as access_role
    FROM dbc_canvases c
    JOIN dbc_canvas_members cm ON cm.canvas_id = c.id
    JOIN dbc_users u ON u.id = c.owner_id
    WHERE cm.user_id = ? AND c.is_active = 1
    ORDER BY id ASC
");
$stmt->execute([$user['id'], $user['id']]);
$all_canvases = $stmt->fetchAll();

// Check for requested canvas (collab switch)
$active_canvas_id = (int)($_GET['canvas'] ?? $canvas['id']);
$active_canvas = null;
foreach ($all_canvases as $c) {
    if ($c['id'] == $active_canvas_id) { $active_canvas = $c; break; }
}
if (!$active_canvas) $active_canvas = $canvas;

$app_name = dbc_get_setting('app_name', APP_NAME);
$app_logo = dbc_get_setting('app_logo', '');

// Pending invites count
$stmt2 = $db->prepare("SELECT COUNT(*) as cnt FROM dbc_canvas_invites WHERE invited_user_id = ? AND status = 'pending'");
$stmt2->execute([$user['id']]);
$inv = $stmt2->fetch();
$pending_invites_count = (int)($inv['cnt'] ?? 0);

// Pending invites detail (for modal)
$pending_stmt = $db->prepare("
    SELECT i.*, c.name as canvas_name, u.username as inviter_name
    FROM dbc_canvas_invites i
    JOIN dbc_canvases c ON c.id = i.canvas_id
    JOIN dbc_users u ON u.id = i.invited_by
    WHERE i.invited_user_id = ? AND i.status = 'pending'
");
$pending_stmt->execute([$user['id']]);
$pending_invites = $pending_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title><?= htmlspecialchars($app_name) ?> — Canvas</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ── Reset & Variables ───────────────────────────── */
:root {
  --toolbar-bg: #1a1a28;
  --toolbar-border: #2a2a40;
  --tool-hover: #2a2a40;
  --tool-active: #5b6ef5;
  --accent: #5b6ef5;
  --accent2: #a78bfa;
  --text: #e8e8f0;
  --text-muted: #7878a0;
  --surface: #13131a;
  --surface2: #1c1c28;
  --border: #2a2a3a;
  --error: #f87171;
  --success: #34d399;
  --radius: 10px;
  --sidebar-w: 64px;
}
[data-theme="light"] {
  --toolbar-bg: #f0f0f8;
  --toolbar-border: #d0d0e8;
  --tool-hover: #e0e0f0;
  --surface: #ffffff;
  --surface2: #f5f5fc;
  --border: #d8d8ec;
  --text: #1a1a2e;
  --text-muted: #6060a0;
}

* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { width: 100%; height: 100%; overflow: hidden; }

body {
  background: #1a1a1a;
  font-family: 'DM Sans', sans-serif;
  color: var(--text);
  display: flex;
  flex-direction: column;
}

/* ── Top Bar ───────────────────────────────────────── */
#topbar {
  height: 52px;
  background: var(--toolbar-bg);
  border-bottom: 1px solid var(--toolbar-border);
  display: flex;
  align-items: center;
  padding: 0 16px;
  gap: 16px;
  flex-shrink: 0;
  z-index: 100;
  user-select: none;
}

.topbar-logo {
  display: flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
}

.topbar-logo img { height: 28px; }
.topbar-logo span {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 15px;
  background: linear-gradient(135deg, var(--text) 0%, var(--accent2) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

#canvas-name-display {
  flex: 1;
  text-align: center;
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: 15px;
  color: var(--text);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
#canvas-name-display:hover { opacity: 0.8; }

.canvas-type-badge {
  font-size: 10px;
  background: var(--accent);
  color: white;
  padding: 2px 8px;
  border-radius: 20px;
  font-family: 'DM Sans', sans-serif;
  font-weight: 500;
  text-transform: uppercase;
}
.canvas-type-badge.collab { background: #059669; }

.topbar-actions { display: flex; align-items: center; gap: 8px; }

.tb-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 8px;
  border: 1px solid var(--toolbar-border);
  background: transparent;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s;
}
.tb-btn:hover { background: var(--tool-hover); }
.tb-btn.icon-only { padding: 7px 9px; }
.tb-btn.active { background: var(--accent); border-color: var(--accent); color: white; }

#save-indicator {
  font-size: 12px;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  gap: 4px;
}
#save-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--success);
}
#save-dot.unsaved { background: var(--error); }

/* ── Main Layout ──────────────────────────────────── */
#main {
  flex: 1;
  display: flex;
  overflow: hidden;
  position: relative;
}

/* ── Toolbar ──────────────────────────────────────── */
#toolbar {
  width: var(--sidebar-w);
  background: var(--toolbar-bg);
  border-right: 1px solid var(--toolbar-border);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px 0;
  gap: 4px;
  z-index: 50;
  flex-shrink: 0;
  overflow-y: auto;
}

.tool-btn {
  width: 44px;
  height: 44px;
  border-radius: var(--radius);
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-muted);
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s;
  position: relative;
}
.tool-btn:hover { background: var(--tool-hover); color: var(--text); }
.tool-btn.active {
  background: var(--accent);
  color: white;
  border-color: rgba(255,255,255,0.2);
  box-shadow: 0 4px 12px rgba(91,110,245,0.4);
}

.tool-sep {
  width: 32px;
  height: 1px;
  background: var(--toolbar-border);
  margin: 4px 0;
}

.tool-tooltip {
  position: absolute;
  left: calc(100% + 8px);
  top: 50%;
  transform: translateY(-50%);
  background: #1a1a28;
  border: 1px solid var(--border);
  color: var(--text);
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.15s;
  z-index: 200;
}
.tool-btn:hover .tool-tooltip { opacity: 1; }

/* ── Tool Options Panel ───────────────────────────── */
#tool-options {
  position: absolute;
  left: calc(var(--sidebar-w) + 8px);
  top: 8px;
  background: var(--toolbar-bg);
  border: 1px solid var(--toolbar-border);
  border-radius: 12px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 12px;
  z-index: 60;
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
  flex-wrap: wrap;
}

.option-group {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--text-muted);
}

.option-group label { white-space: nowrap; }

input[type="range"] {
  -webkit-appearance: none;
  width: 80px;
  height: 4px;
  background: var(--border);
  border-radius: 2px;
  outline: none;
}
input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--accent);
  cursor: pointer;
}

#color-picker-btn {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 2px solid var(--border);
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
#color-picker-btn input[type="color"] {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
  width: 100%;
  height: 100%;
}

.color-swatches {
  display: flex;
  gap: 4px;
}
.color-swatch {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  cursor: pointer;
  border: 2px solid transparent;
  transition: transform 0.1s, border-color 0.1s;
}
.color-swatch:hover { transform: scale(1.2); }
.color-swatch.selected { border-color: white; }

/* ── Canvas Area ──────────────────────────────────── */
#canvas-container {
  flex: 1;
  position: relative;
  overflow: hidden;
  background: #888;
  background-image: 
    linear-gradient(45deg, #999 25%, transparent 25%),
    linear-gradient(-45deg, #999 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #999 75%),
    linear-gradient(-45deg, transparent 75%, #999 75%);
  background-size: 12px 12px;
  background-position: 0 0, 0 6px, 6px -6px, -6px 0px;
}

#canvas-viewport {
  position: absolute;
  transform-origin: 0 0;
  cursor: crosshair;
}

#draw-canvas {
  display: block;
  touch-action: none;
}

#overlay-layer {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

/* ── Sticky Notes ─────────────────────────────────── */
.sticky-note {
  position: absolute;
  border-radius: 4px;
  padding: 8px;
  min-width: 150px;
  min-height: 120px;
  cursor: move;
  box-shadow: 2px 4px 12px rgba(0,0,0,0.3);
  user-select: none;
  resize: both;
  overflow: auto;
  pointer-events: all;
}

.sticky-note-header {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 4px;
  gap: 4px;
}

.sticky-btn {
  width: 20px;
  height: 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0,0,0,0.15);
  color: rgba(0,0,0,0.6);
}
.sticky-btn:hover { background: rgba(0,0,0,0.3); }

.sticky-text {
  width: 100%;
  border: none;
  background: transparent;
  font-family: 'DM Sans', sans-serif;
  font-size: 13px;
  line-height: 1.5;
  color: #1a1a1a;
  resize: none;
  outline: none;
  height: calc(100% - 28px);
  min-height: 80px;
}

/* ── Canvas Images ────────────────────────────────── */
.canvas-image {
  position: absolute;
  cursor: move;
  border: 2px solid transparent;
  border-radius: 4px;
  user-select: none;
  pointer-events: all;
}
.canvas-image.selected { border-color: var(--accent); }
.canvas-image img { width: 100%; height: 100%; object-fit: contain; display: block; pointer-events: none; }
.resize-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background: var(--accent);
  border-radius: 2px;
  cursor: se-resize;
  bottom: -5px;
  right: -5px;
}

/* ── Text Boxes ───────────────────────────────────── */
.canvas-text {
  position: absolute;
  min-width: 100px;
  min-height: 30px;
  cursor: move;
  pointer-events: all;
  border: 1px dashed transparent;
}
.canvas-text:hover { border-color: var(--accent); }
.canvas-text textarea {
  width: 100%;
  min-height: 30px;
  border: none;
  background: transparent;
  font-family: 'DM Sans', sans-serif;
  font-size: 16px;
  color: inherit;
  outline: none;
  resize: both;
  cursor: text;
}

/* ── Modals ───────────────────────────────────────── */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(4px);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s;
}
.modal-overlay.open { opacity: 1; pointer-events: all; }

.modal {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 32px;
  width: 100%;
  max-width: 480px;
  max-height: 90vh;
  overflow-y: auto;
  margin: 20px;
  box-shadow: 0 32px 80px rgba(0,0,0,0.6);
  transform: scale(0.95);
  transition: transform 0.2s;
}
.modal-overlay.open .modal { transform: scale(1); }

.modal h2 {
  font-family: 'Syne', sans-serif;
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.modal-close {
  margin-left: auto;
  background: none;
  border: none;
  color: var(--text-muted);
  font-size: 20px;
  cursor: pointer;
  padding: 0 4px;
}
.modal-close:hover { color: var(--text); }

.modal-section {
  border-bottom: 1px solid var(--border);
  padding-bottom: 20px;
  margin-bottom: 20px;
}
.modal-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
.modal-section h3 { font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--text-muted); margin-bottom: 12px; }

.modal input[type="text"],
.modal input[type="password"],
.modal input[type="color"] {
  width: 100%;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 10px 14px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  outline: none;
  margin-bottom: 10px;
}
.modal input:focus { border-color: var(--accent); }

.modal-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 9px 18px;
  border-radius: var(--radius);
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  border: none;
  transition: all 0.15s;
}
.modal-btn-primary { background: var(--accent); color: white; }
.modal-btn-primary:hover { opacity: 0.9; }
.modal-btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border); }
.modal-btn-secondary:hover { background: var(--border); }
.modal-btn-danger { background: rgba(248,113,113,0.15); color: var(--error); border: 1px solid rgba(248,113,113,0.3); }
.modal-btn-danger:hover { background: rgba(248,113,113,0.25); }

.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0;
}
.toggle-row span { font-size: 14px; }

.toggle {
  width: 42px;
  height: 24px;
  background: var(--border);
  border-radius: 12px;
  position: relative;
  cursor: pointer;
  border: none;
  transition: background 0.2s;
}
.toggle.on { background: var(--accent); }
.toggle::after {
  content: '';
  position: absolute;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: white;
  top: 3px;
  left: 3px;
  transition: left 0.2s;
}
.toggle.on::after { left: 21px; }

.color-picker-large {
  width: 100%;
  height: 40px;
  padding: 2px;
  border-radius: var(--radius);
  border: 1px solid var(--border);
  background: var(--surface2);
  cursor: pointer;
}

/* Invite card */
.invite-code-box {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
}
.invite-code {
  flex: 1;
  font-family: monospace;
  font-size: 18px;
  letter-spacing: 3px;
  color: var(--accent);
}
.copy-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 18px;
  padding: 4px;
}

/* Canvas switcher list */
.canvas-list { display: flex; flex-direction: column; gap: 8px; }
.canvas-item {
  display: flex;
  align-items: center;
  gap: 10px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 10px 14px;
  cursor: pointer;
  transition: all 0.15s;
  text-decoration: none;
  color: var(--text);
}
.canvas-item:hover { border-color: var(--accent); background: rgba(91,110,245,0.08); }
.canvas-item.current { border-color: var(--accent); }
.canvas-item-icon { font-size: 20px; }
.canvas-item-info { flex: 1; }
.canvas-item-name { font-weight: 500; font-size: 14px; }
.canvas-item-meta { font-size: 12px; color: var(--text-muted); }

/* Notifications */
.toast {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: var(--surface);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 10px 20px;
  border-radius: 20px;
  font-size: 14px;
  z-index: 9999;
  transition: transform 0.3s;
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  white-space: nowrap;
}
.toast.show { transform: translateX(-50%) translateY(0); }

/* Collab users indicator */
#collab-users {
  display: flex;
  align-items: center;
  gap: -6px;
}
.collab-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 2px solid var(--toolbar-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
  color: white;
  margin-left: -6px;
}
.collab-avatar:first-child { margin-left: 0; }

/* Upload zone in modal */
.upload-zone {
  border: 2px dashed var(--border);
  border-radius: var(--radius);
  padding: 24px;
  text-align: center;
  cursor: pointer;
  transition: all 0.15s;
  position: relative;
  color: var(--text-muted);
  font-size: 14px;
}
.upload-zone:hover { border-color: var(--accent); background: rgba(91,110,245,0.05); }
.upload-zone input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }

/* Pending invites badge */
.invite-badge {
  background: var(--error);
  color: white;
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 10px;
  font-weight: 700;
}

@media (max-width: 600px) {
  #toolbar { width: 52px; --sidebar-w: 52px; }
  .tool-btn { width: 38px; height: 38px; font-size: 18px; }
}
</style>
</head>
<body data-theme="dark">

<!-- Top Bar -->
<div id="topbar">
  <a href="#" class="topbar-logo" onclick="openModal('canvasModal');return false;">
    <?php if ($app_logo && file_exists(dirname(__FILE__, 2) . '/' . $app_logo)): ?>
      <img src="<?= htmlspecialchars(dbc_app_url($app_logo)) ?>" alt="logo">
    <?php else: ?>
      🌉
    <?php endif; ?>
    <span><?= htmlspecialchars($app_name) ?></span>
  </a>

  <div id="canvas-name-display" onclick="openModal('canvasModal')">
    <span id="canvas-title-text"><?= htmlspecialchars($active_canvas['name']) ?></span>
    <span class="canvas-type-badge <?= $active_canvas['type'] === 'collaborative' ? 'collab' : '' ?>">
      <?= $active_canvas['type'] === 'collaborative' ? '👥 Collab' : '🔒 Personal' ?>
    </span>
  </div>

  <div class="topbar-actions">
    <div id="collab-users"></div>

    <div id="save-indicator">
      <div id="save-dot"></div>
      <span id="save-text">Saved</span>
    </div>

    <?php if ($user['role'] === 'admin'): ?>
    <a href="<?= htmlspecialchars(dbc_app_url('admin/index.php')) ?>" class="tb-btn">⚙️ Admin</a>
    <?php endif; ?>

    <button class="tb-btn" onclick="openModal('settingsModal')">
      ⚙️ Settings
    </button>

    <button class="tb-btn icon-only" onclick="openModal('canvasModal')" title="Switch Canvas">
      🗂️
      <?php if ($pending_invites_count > 0): ?>
        <span class="invite-badge"><?= $pending_invites_count ?></span>
      <?php endif; ?>
    </button>

    <a href="<?= htmlspecialchars(dbc_app_url('auth/logout.php')) ?>" class="tb-btn icon-only" title="Logout">🚪</a>
  </div>
</div>

<!-- Main Layout -->
<div id="main">
  <!-- Toolbar -->
  <div id="toolbar">
    <button class="tool-btn active" id="tool-pen" onclick="setTool('pen')" title="Pen">
      ✏️ <span class="tool-tooltip">Pen</span>
    </button>
    <button class="tool-btn" id="tool-grab" onclick="setTool('grab')" title="Grab">
      ✋ <span class="tool-tooltip">Grab / Move</span>
    </button>
    <button class="tool-btn" id="tool-eraser" onclick="setTool('eraser')" title="Eraser">
      🧹 <span class="tool-tooltip">Eraser</span>
    </button>

    <div class="tool-sep"></div>

    <button class="tool-btn" id="tool-text" onclick="setTool('text')" title="Text">
      T <span class="tool-tooltip">Text</span>
    </button>
    <button class="tool-btn" id="tool-note" onclick="addStickyNote()" title="Sticky Note">
      📝 <span class="tool-tooltip">Sticky Note</span>
    </button>
    <button class="tool-btn" id="tool-image" onclick="document.getElementById('image-upload').click()" title="Upload Image">
      🖼️ <span class="tool-tooltip">Upload Image</span>
    </button>

    <div class="tool-sep"></div>

    <button class="tool-btn" id="btn-undo" onclick="undo()" title="Undo">
      ↩️ <span class="tool-tooltip">Undo (Ctrl+Z)</span>
    </button>
    <button class="tool-btn" id="btn-redo" onclick="redo()" title="Redo">
      ↪️ <span class="tool-tooltip">Redo (Ctrl+Y)</span>
    </button>

    <div class="tool-sep"></div>

    <button class="tool-btn" onclick="openModal('settingsModal')" title="Settings">
      ⚙️ <span class="tool-tooltip">Settings</span>
    </button>
  </div>

  <!-- Tool Options -->
  <div id="tool-options">
    <div class="option-group" id="opt-size">
      <label>Size</label>
      <input type="range" id="brush-size" min="1" max="60" value="4" oninput="updateBrushSize(this.value)">
      <span id="brush-size-val">4px</span>
    </div>
    <div class="option-group" id="opt-color">
      <label>Colour</label>
      <div id="color-picker-btn">
        <input type="color" id="pen-color" value="#5b6ef5" oninput="updateColor(this.value)">
      </div>
      <div class="color-swatches" id="color-swatches"></div>
    </div>
    <div class="option-group" id="opt-opacity" style="display:none">
      <label>Opacity</label>
      <input type="range" id="opacity-slider" min="10" max="100" value="100" oninput="updateOpacity(this.value)">
      <span id="opacity-val">100%</span>
    </div>
  </div>

  <!-- Canvas Container -->
  <div id="canvas-container">
    <div id="canvas-viewport">
      <canvas id="draw-canvas"></canvas>
      <div id="overlay-layer"></div>
    </div>
  </div>
</div>

<!-- Hidden file input for image upload -->
<input type="file" id="image-upload" accept="image/*" style="display:none" onchange="handleImageUpload(this)">

<!-- ════ MODALS ════ -->

<!-- Settings Modal -->
<div class="modal-overlay" id="settingsModal">
<div class="modal">
  <h2>⚙️ Settings <button class="modal-close" onclick="closeModal('settingsModal')">✕</button></h2>

  <!-- Background -->
  <div class="modal-section">
    <h3>🖼️ Background</h3>
    <div class="upload-zone" style="margin-bottom:10px;">
      <input type="file" accept="image/*" onchange="setBackgroundImage(this)">
      📁 Upload background image
    </div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
      <label style="font-size:13px;color:var(--text-muted)">Canvas colour</label>
      <input type="color" id="bg-color-picker" class="color-picker-large" value="#ffffff" onchange="setBackgroundColor(this.value)">
    </div>
    <button class="modal-btn modal-btn-secondary" onclick="clearBackground()" style="font-size:13px;">✕ Clear background image</button>
  </div>

  <!-- Theme -->
  <div class="modal-section">
    <h3>🌗 Appearance</h3>
    <div class="toggle-row">
      <span>Light / Dark Mode</span>
      <button class="toggle" id="theme-toggle" onclick="toggleTheme(this)"></button>
    </div>
  </div>

  <!-- Current Canvas -->
  <div class="modal-section">
    <h3>📋 Current Canvas</h3>
    <div style="font-size:13px;color:var(--text-muted);margin-bottom:10px;">
      You are on: <strong style="color:var(--text)"><?= htmlspecialchars($active_canvas['name']) ?></strong>
      (<?= $active_canvas['type'] ?>)
    </div>
    <button class="modal-btn modal-btn-secondary" onclick="openModal('canvasModal');closeModal('settingsModal');">🗂️ Switch / Manage Canvases</button>
  </div>

  <!-- Password Change -->
  <div class="modal-section">
    <h3>🔑 Change Password</h3>
    <input type="password" id="pw-current" placeholder="Current password">
    <input type="password" id="pw-new" placeholder="New password">
    <input type="password" id="pw-confirm" placeholder="Confirm new password">
    <button class="modal-btn modal-btn-primary" onclick="changePassword()">Update Password</button>
    <div id="pw-result" style="margin-top:8px;font-size:13px;"></div>
  </div>
</div>
</div>

<!-- Canvas Switcher Modal -->
<div class="modal-overlay" id="canvasModal">
<div class="modal">
  <h2>🗂️ Canvases <button class="modal-close" onclick="closeModal('canvasModal')">✕</button></h2>

  <!-- Pending Invites -->
  <?php if ($pending_invites): ?>
  <div class="modal-section">
    <h3>📬 Pending Invites</h3>
    <?php foreach ($pending_invites as $inv): ?>
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;">
      <div style="flex:1;font-size:13px;">
        <strong><?= htmlspecialchars($inv['inviter_name']) ?></strong> invited you to <strong><?= htmlspecialchars($inv['canvas_name']) ?></strong>
      </div>
      <button class="modal-btn modal-btn-primary" style="padding:6px 12px;font-size:12px;" onclick="respondInvite(<?= $inv['id'] ?>,'accepted')">Accept</button>
      <button class="modal-btn modal-btn-secondary" style="padding:6px 12px;font-size:12px;" onclick="respondInvite(<?= $inv['id'] ?>,'declined')">Decline</button>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Canvas List -->
  <div class="modal-section">
    <h3>My Canvases</h3>
    <div class="canvas-list">
      <?php foreach ($all_canvases as $c): ?>
      <a href="?canvas=<?= $c['id'] ?>" class="canvas-item <?= $c['id'] == $active_canvas['id'] ? 'current' : '' ?>">
        <div class="canvas-item-icon"><?= $c['type'] === 'collaborative' ? '👥' : '🔒' ?></div>
        <div class="canvas-item-info">
          <div class="canvas-item-name"><?= htmlspecialchars($c['name']) ?></div>
          <div class="canvas-item-meta">
            <?= $c['type'] === 'collaborative' ? 'Collaborative' : 'Personal' ?>
            <?php if ($c['type'] === 'collaborative' && $c['owner_id'] != $user['id']): ?>
              · by <?= htmlspecialchars($c['owner_name']) ?>
            <?php endif; ?>
          </div>
        </div>
        <?php if ($c['id'] == $active_canvas['id']): ?><span style="color:var(--accent)">●</span><?php endif; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Create Collab Canvas -->
  <div class="modal-section">
    <h3>➕ Create Collaborative Canvas</h3>
    <div style="display:flex;gap:8px;">
      <input type="text" id="new-canvas-name" placeholder="Canvas name" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:9px 12px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:13px;outline:none;">
      <button class="modal-btn modal-btn-primary" onclick="createCollabCanvas()">Create</button>
    </div>
  </div>

  <!-- Invite to current collab canvas -->
  <?php if ($active_canvas['type'] === 'collaborative' && $active_canvas['owner_id'] == $user['id']): ?>
  <div class="modal-section">
    <h3>📨 Invite to "<?= htmlspecialchars($active_canvas['name']) ?>"</h3>
    <div style="display:flex;gap:8px;">
      <input type="text" id="invite-username" placeholder="Username to invite" style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:9px 12px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:13px;outline:none;">
      <button class="modal-btn modal-btn-primary" onclick="sendInvite()">Invite</button>
    </div>
    <div id="invite-result" style="margin-top:8px;font-size:13px;"></div>
  </div>
  <?php elseif ($active_canvas['type'] === 'personal'): ?>
  <div class="modal-section">
    <h3>💡 Tip</h3>
    <p style="font-size:13px;color:var(--text-muted)">Create a collaborative canvas above to invite others and work together in real time.</p>
  </div>
  <?php endif; ?>
</div>
</div>

<!-- Toast -->
<div id="toast" class="toast"></div>

<script>
// ─── State ──────────────────────────────────────────
const STATE = {
  canvasId: <?= (int)$active_canvas['id'] ?>,
  userId: <?= (int)$user['id'] ?>,
  username: <?= json_encode($user['username']) ?>,
  isCollab: <?= $active_canvas['type'] === 'collaborative' ? 'true' : 'false' ?>,
  tool: 'pen',
  color: '#5b6ef5',
  brushSize: 4,
  opacity: 1,
  isDrawing: false,
  lastX: 0, lastY: 0,
  scale: 1,
  panX: 0, panY: 0,
  isPanning: false,
  panStartX: 0, panStartY: 0,
  history: [],
  redoStack: [],
  lastSyncId: 0,
  saveTimeout: null,
  isDirty: false,
  theme: 'dark',
};

const COLORS = ['#f87171','#fb923c','#fbbf24','#34d399','#60a5fa','#a78bfa','#f472b6','#ffffff','#000000','#5b6ef5'];

// ─── Init ────────────────────────────────────────────
const container = document.getElementById('canvas-container');
const viewport  = document.getElementById('canvas-viewport');
const canvas    = document.getElementById('draw-canvas');
const ctx       = canvas.getContext('2d');
const overlay   = document.getElementById('overlay-layer');

function initCanvas() {
  resizeCanvas();
  loadCanvasData();
  buildColorSwatches();
  updateColorBtn();
  bindEvents();
  if (STATE.isCollab) startPolling();
  setInterval(updateActiveSessions, 15000);
}

function resizeCanvas() {
  const W = container.clientWidth;
  const H = container.clientHeight;
  canvas.width  = Math.max(W * 2, 2000);
  canvas.height = Math.max(H * 2, 2000);
  overlay.style.width  = canvas.width + 'px';
  overlay.style.height = canvas.height + 'px';
  redrawAll();
}

// ─── Tools ──────────────────────────────────────────
function setTool(tool) {
  STATE.tool = tool;
  document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
  const btn = document.getElementById('tool-' + tool);
  if (btn) btn.classList.add('active');

  canvas.style.cursor = {
    pen: 'crosshair',
    grab: 'grab',
    eraser: 'cell',
    text: 'text',
  }[tool] || 'default';

  document.getElementById('opt-size').style.display = (tool === 'pen' || tool === 'eraser') ? 'flex' : 'none';
  document.getElementById('opt-color').style.display = (tool === 'pen' || tool === 'text') ? 'flex' : 'none';
}

// ─── Color ──────────────────────────────────────────
function buildColorSwatches() {
  const cont = document.getElementById('color-swatches');
  cont.innerHTML = COLORS.map(c =>
    `<div class="color-swatch ${c === STATE.color ? 'selected' : ''}"
       style="background:${c}" onclick="selectColor('${c}')"></div>`
  ).join('');
}

function selectColor(c) {
  STATE.color = c;
  document.getElementById('pen-color').value = c;
  updateColorBtn();
  buildColorSwatches();
}

function updateColor(c) {
  STATE.color = c;
  updateColorBtn();
  buildColorSwatches();
}

function updateColorBtn() {
  document.getElementById('color-picker-btn').style.background = STATE.color;
}

function updateBrushSize(v) {
  STATE.brushSize = parseInt(v);
  document.getElementById('brush-size-val').textContent = v + 'px';
}

function updateOpacity(v) {
  STATE.opacity = v / 100;
  document.getElementById('opacity-val').textContent = v + '%';
}

// ─── Drawing ──────────────────────────────────────────
function getCanvasPos(e) {
  const rect = canvas.getBoundingClientRect();
  const touch = e.touches ? e.touches[0] : e;
  return {
    x: (touch.clientX - rect.left) / STATE.scale,
    y: (touch.clientY - rect.top)  / STATE.scale,
  };
}

function bindEvents() {
  canvas.addEventListener('mousedown', onStart);
  canvas.addEventListener('mousemove', onMove);
  canvas.addEventListener('mouseup', onEnd);
  canvas.addEventListener('mouseleave', onEnd);
  canvas.addEventListener('touchstart', e => { e.preventDefault(); onStart(e); }, {passive: false});
  canvas.addEventListener('touchmove', e => { e.preventDefault(); onMove(e); }, {passive: false});
  canvas.addEventListener('touchend', e => { e.preventDefault(); onEnd(e); }, {passive: false});
  canvas.addEventListener('wheel', onWheel, {passive: false});
  document.addEventListener('keydown', onKeydown);
}

let currentStroke = [];

function onStart(e) {
  if (STATE.tool === 'grab') {
    STATE.isPanning = true;
    const touch = e.touches ? e.touches[0] : e;
    STATE.panStartX = touch.clientX - STATE.panX;
    STATE.panStartY = touch.clientY - STATE.panY;
    canvas.style.cursor = 'grabbing';
    return;
  }
  if (STATE.tool === 'text') { addTextBox(e); return; }

  STATE.isDrawing = true;
  const pos = getCanvasPos(e);
  STATE.lastX = pos.x;
  STATE.lastY = pos.y;
  currentStroke = [{x: pos.x, y: pos.y}];

  ctx.globalAlpha = STATE.opacity;
  ctx.strokeStyle = STATE.tool === 'eraser' ? '#ffffff' : STATE.color;
  ctx.lineWidth   = STATE.brushSize;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';
  if (STATE.tool === 'eraser') ctx.globalCompositeOperation = 'destination-out';
  else ctx.globalCompositeOperation = 'source-over';

  ctx.beginPath();
  ctx.moveTo(pos.x, pos.y);
}

function onMove(e) {
  if (STATE.isPanning) {
    const touch = e.touches ? e.touches[0] : e;
    STATE.panX = touch.clientX - STATE.panStartX;
    STATE.panY = touch.clientY - STATE.panStartY;
    applyTransform();
    return;
  }
  if (!STATE.isDrawing) return;
  const pos = getCanvasPos(e);
  ctx.lineTo(pos.x, pos.y);
  ctx.stroke();
  currentStroke.push({x: pos.x, y: pos.y});
  STATE.lastX = pos.x;
  STATE.lastY = pos.y;
}

function onEnd(e) {
  if (STATE.isPanning) {
    STATE.isPanning = false;
    canvas.style.cursor = 'grab';
    return;
  }
  if (!STATE.isDrawing) return;
  STATE.isDrawing = false;
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';

  if (currentStroke.length > 1) {
    const stroke = {
      type: STATE.tool === 'eraser' ? 'erase' : 'draw',
      color: STATE.color,
      size: STATE.brushSize,
      opacity: STATE.opacity,
      points: currentStroke,
    };
    STATE.history.push(stroke);
    STATE.redoStack = [];
    markDirty();
    if (STATE.isCollab) syncStroke(stroke);
  }
  currentStroke = [];
}

function onWheel(e) {
  e.preventDefault();
  const scaleFactor = e.deltaY > 0 ? 0.9 : 1.1;
  STATE.scale = Math.min(Math.max(STATE.scale * scaleFactor, 0.1), 5);
  applyTransform();
}

function applyTransform() {
  viewport.style.transform = `translate(${STATE.panX}px, ${STATE.panY}px) scale(${STATE.scale})`;
}

function onKeydown(e) {
  if (e.ctrlKey || e.metaKey) {
    if (e.key === 'z') { e.preventDefault(); undo(); }
    if (e.key === 'y') { e.preventDefault(); redo(); }
  }
}

// ─── History ──────────────────────────────────────────
function saveSnapshot() {
  return ctx.getImageData(0, 0, canvas.width, canvas.height);
}

function undo() {
  if (STATE.history.length === 0) return;
  STATE.redoStack.push(STATE.history.pop());
  redrawAll();
  markDirty();
}

function redo() {
  if (STATE.redoStack.length === 0) return;
  const stroke = STATE.redoStack.pop();
  STATE.history.push(stroke);
  drawStroke(stroke);
  markDirty();
}

function redrawAll() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // Re-apply background
  if (STATE.bgColor) {
    ctx.fillStyle = STATE.bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  if (STATE.bgImage) {
    ctx.drawImage(STATE.bgImage, 0, 0, canvas.width, canvas.height);
  }
  STATE.history.forEach(drawStroke);
}

function drawStroke(stroke) {
  if (!stroke.points || stroke.points.length < 2) return;
  ctx.save();
  ctx.globalAlpha = stroke.opacity ?? 1;
  ctx.strokeStyle = stroke.type === 'erase' ? '#ffffff' : stroke.color;
  ctx.lineWidth   = stroke.size;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';
  if (stroke.type === 'erase') ctx.globalCompositeOperation = 'destination-out';
  else ctx.globalCompositeOperation = 'source-over';
  ctx.beginPath();
  ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
  stroke.points.slice(1).forEach(p => ctx.lineTo(p.x, p.y));
  ctx.stroke();
  ctx.restore();
}

// ─── Text Boxes ───────────────────────────────────────
function addTextBox(e) {
  const pos = getCanvasPos(e);
  const box = document.createElement('div');
  box.className = 'canvas-text';
  box.style.left = pos.x + 'px';
  box.style.top  = pos.y + 'px';
  box.style.color = STATE.color;

  const ta = document.createElement('textarea');
  ta.rows = 2;
  ta.placeholder = 'Type here...';
  ta.style.color = STATE.color;
  box.appendChild(ta);
  overlay.appendChild(box);

  makeDraggable(box);
  ta.focus();
  ta.addEventListener('input', () => markDirty());
}

// ─── Sticky Notes ─────────────────────────────────────
const NOTE_COLORS = ['#fef08a','#86efac','#93c5fd','#f9a8d4','#fdba74','#c4b5fd'];

function addStickyNote() {
  const note = createStickyEl({
    x: 200 + Math.random() * 200,
    y: 200 + Math.random() * 100,
    color: NOTE_COLORS[Math.floor(Math.random() * NOTE_COLORS.length)],
    content: '',
  });
  overlay.appendChild(note);
  markDirty();
}

function createStickyEl(data) {
  const note = document.createElement('div');
  note.className = 'sticky-note';
  note.style.left    = data.x + 'px';
  note.style.top     = data.y + 'px';
  note.style.background = data.color;
  note.style.width   = (data.width  || 180) + 'px';
  note.style.height  = (data.height || 150) + 'px';

  note.innerHTML = `
    <div class="sticky-note-header">
      ${NOTE_COLORS.map(c => `<div style="width:14px;height:14px;border-radius:50%;background:${c};cursor:pointer;flex-shrink:0;border:1px solid rgba(0,0,0,0.2);" onclick="this.closest('.sticky-note').style.background='${c}'"></div>`).join('')}
      <button class="sticky-btn" onclick="this.closest('.sticky-note').remove();markDirty()">✕</button>
    </div>
    <textarea class="sticky-text" placeholder="Note...">${data.content || ''}</textarea>
  `;

  makeDraggable(note);
  note.querySelector('textarea').addEventListener('input', () => markDirty());
  return note;
}

// ─── Images on Canvas ────────────────────────────────
function handleImageUpload(input) {
  if (!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    addImageToCanvas(e.target.result, 200, 200);
    markDirty();
  };
  reader.readAsDataURL(input.files[0]);
  input.value = '';
}

function addImageToCanvas(src, x, y, w, h) {
  const wrap = document.createElement('div');
  wrap.className = 'canvas-image';
  wrap.style.left   = x + 'px';
  wrap.style.top    = y + 'px';
  wrap.style.width  = (w || 300) + 'px';
  wrap.style.height = (h || 200) + 'px';

  const img = document.createElement('img');
  img.src = src;
  img.draggable = false;

  const handle = document.createElement('div');
  handle.className = 'resize-handle';

  wrap.appendChild(img);
  wrap.appendChild(handle);
  overlay.appendChild(wrap);

  wrap.addEventListener('click', () => {
    document.querySelectorAll('.canvas-image').forEach(el => el.classList.remove('selected'));
    wrap.classList.add('selected');
  });

  makeDraggable(wrap);
  makeResizable(wrap, handle);
}

// ─── Drag Utility ────────────────────────────────────
function makeDraggable(el) {
  let ox, oy, isDragging = false;

  el.addEventListener('mousedown', e => {
    if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON' || e.target.classList.contains('resize-handle')) return;
    isDragging = true;
    ox = e.clientX - el.offsetLeft;
    oy = e.clientY - el.offsetTop;
    el.style.zIndex = Date.now();
    e.preventDefault();
  });

  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    el.style.left = (e.clientX - ox) + 'px';
    el.style.top  = (e.clientY - oy) + 'px';
    markDirty();
  });

  document.addEventListener('mouseup', () => { isDragging = false; });
}

function makeResizable(el, handle) {
  let isDragging = false, startX, startY, startW, startH;

  handle.addEventListener('mousedown', e => {
    isDragging = true;
    startX = e.clientX; startY = e.clientY;
    startW = el.offsetWidth; startH = el.offsetHeight;
    e.preventDefault(); e.stopPropagation();
  });

  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    el.style.width  = Math.max(80, startW + e.clientX - startX) + 'px';
    el.style.height = Math.max(60, startH + e.clientY - startY) + 'px';
    markDirty();
  });

  document.addEventListener('mouseup', () => { isDragging = false; });
}

// ─── Background ──────────────────────────────────────
STATE.bgColor = '#ffffff';
STATE.bgImage = null;

function setBackgroundColor(color) {
  STATE.bgColor = color;
  document.getElementById('canvas-container').style.background = 'none';
  redrawAll();
  markDirty();
  saveCanvasSetting('background_color', color);
}

function setBackgroundImage(input) {
  if (!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      STATE.bgImage = img;
      redrawAll();
      markDirty();
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(input.files[0]);
}

function clearBackground() {
  STATE.bgImage = null;
  redrawAll();
  markDirty();
  saveCanvasSetting('background_image', '');
}

// ─── Theme ───────────────────────────────────────────
function toggleTheme(btn) {
  STATE.theme = STATE.theme === 'dark' ? 'light' : 'dark';
  document.body.dataset.theme = STATE.theme;
  btn.classList.toggle('on');

  if (STATE.theme === 'light') {
    setBackgroundColor('#ffffff');
    STATE.color = '#000000';
  } else {
    setBackgroundColor('#1a1a2e');
    STATE.color = '#ffffff';
  }
  updateColorBtn();
  document.getElementById('pen-color').value = STATE.color;
}

// ─── Save / Load ─────────────────────────────────────
function markDirty() {
  STATE.isDirty = true;
  const dot = document.getElementById('save-dot');
  const txt = document.getElementById('save-text');
  dot.classList.add('unsaved');
  txt.textContent = 'Unsaved';
  clearTimeout(STATE.saveTimeout);
  STATE.saveTimeout = setTimeout(autoSave, 2000);
}

async function autoSave() {
  const data = serializeCanvas();
  try {
    const res = await fetch('../api/canvas.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        action: 'save',
        canvas_id: STATE.canvasId,
        data: data,
      })
    });
    const json = await res.json();
    if (json.success) {
      STATE.isDirty = false;
      document.getElementById('save-dot').classList.remove('unsaved');
      document.getElementById('save-text').textContent = 'Saved';
    }
  } catch(e) { console.error('Save failed', e); }
}

function serializeCanvas() {
  // Get overlay elements
  const notes = [];
  document.querySelectorAll('.sticky-note').forEach(el => {
    notes.push({
      x: parseFloat(el.style.left),
      y: parseFloat(el.style.top),
      w: el.offsetWidth,
      h: el.offsetHeight,
      color: el.style.background,
      content: el.querySelector('textarea')?.value || '',
    });
  });

  const images = [];
  document.querySelectorAll('.canvas-image').forEach(el => {
    images.push({
      src: el.querySelector('img')?.src || '',
      x: parseFloat(el.style.left),
      y: parseFloat(el.style.top),
      w: el.offsetWidth,
      h: el.offsetHeight,
    });
  });

  const texts = [];
  document.querySelectorAll('.canvas-text').forEach(el => {
    texts.push({
      x: parseFloat(el.style.left),
      y: parseFloat(el.style.top),
      content: el.querySelector('textarea')?.value || '',
      color: el.style.color || STATE.color,
    });
  });

  return {
    strokes: STATE.history,
    notes,
    images,
    texts,
    bgColor: STATE.bgColor,
    canvasDataUrl: canvas.toDataURL('image/png', 0.7),
  };
}

async function loadCanvasData() {
  try {
    const res = await fetch(`../api/canvas.php?action=load&canvas_id=${STATE.canvasId}`);
    const json = await res.json();
    if (json.success && json.data) {
      restoreCanvas(json.data);
    }
  } catch(e) { console.error('Load failed', e); }

  // Apply saved bg color
  const bgColor = <?= json_encode($active_canvas['background_color'] ?? '#ffffff') ?>;
  if (bgColor) {
    STATE.bgColor = bgColor;
    document.getElementById('bg-color-picker').value = bgColor;
  }
}

function restoreCanvas(data) {
  if (!data) return;
  try {
    const parsed = typeof data === 'string' ? JSON.parse(data) : data;

    if (parsed.bgColor) {
      STATE.bgColor = parsed.bgColor;
      document.getElementById('bg-color-picker').value = parsed.bgColor;
    }

    // Restore strokes
    if (parsed.strokes) {
      STATE.history = parsed.strokes;
      redrawAll();
    } else if (parsed.canvasDataUrl) {
      // Legacy: restore from image
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0);
      img.src = parsed.canvasDataUrl;
    }

    // Restore notes
    if (parsed.notes) {
      parsed.notes.forEach(n => overlay.appendChild(createStickyEl(n)));
    }

    // Restore images
    if (parsed.images) {
      parsed.images.forEach(im => addImageToCanvas(im.src, im.x, im.y, im.w, im.h));
    }

    // Restore texts
    if (parsed.texts) {
      parsed.texts.forEach(t => {
        const box = document.createElement('div');
        box.className = 'canvas-text';
        box.style.left  = t.x + 'px';
        box.style.top   = t.y + 'px';
        box.style.color = t.color;
        const ta = document.createElement('textarea');
        ta.rows = 2;
        ta.value = t.content;
        ta.style.color = t.color;
        box.appendChild(ta);
        overlay.appendChild(box);
        makeDraggable(box);
        ta.addEventListener('input', () => markDirty());
      });
    }
  } catch(e) { console.error('Restore failed', e); }
}

async function saveCanvasSetting(key, value) {
  try {
    await fetch('../api/canvas.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ action: 'update_setting', canvas_id: STATE.canvasId, key, value })
    });
  } catch(e) {}
}

// ─── Collaboration Polling ────────────────────────────
function startPolling() {
  setInterval(pollStrokes, <?= POLL_INTERVAL ?>);
}

async function pollStrokes() {
  try {
    const res = await fetch(`../api/sync.php?canvas_id=${STATE.canvasId}&since=${STATE.lastSyncId}`);
    const json = await res.json();
    if (json.strokes && json.strokes.length) {
      json.strokes.forEach(s => {
        if (s.user_id !== STATE.userId) {
          const stroke = JSON.parse(s.stroke_data);
          drawStroke(stroke);
          STATE.history.push(stroke);
        }
        STATE.lastSyncId = Math.max(STATE.lastSyncId, s.id);
      });
    }
    if (json.users) updateCollabUsers(json.users);
  } catch(e) {}
}

async function syncStroke(stroke) {
  try {
    await fetch('../api/sync.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        canvas_id: STATE.canvasId,
        stroke_data: JSON.stringify(stroke),
        action: stroke.type === 'erase' ? 'erase' : 'draw',
      })
    });
  } catch(e) {}
}

function updateCollabUsers(users) {
  const cont = document.getElementById('collab-users');
  cont.innerHTML = users.slice(0,5).map(u =>
    `<div class="collab-avatar" style="background:${u.color || '#5b6ef5'}" title="${u.username}">${u.username[0].toUpperCase()}</div>`
  ).join('');
}

async function updateActiveSessions() {
  try {
    await fetch(`../api/sync.php?action=heartbeat&canvas_id=${STATE.canvasId}`, {method:'POST'});
  } catch(e) {}
}

// ─── Password Change ──────────────────────────────────
async function changePassword() {
  const cur = document.getElementById('pw-current').value;
  const nw  = document.getElementById('pw-new').value;
  const cn  = document.getElementById('pw-confirm').value;
  const res = document.getElementById('pw-result');

  if (!cur || !nw || !cn) { res.style.color='var(--error)'; res.textContent='All fields required.'; return; }
  if (nw !== cn) { res.style.color='var(--error)'; res.textContent='New passwords do not match.'; return; }
  if (nw.length < 6) { res.style.color='var(--error)'; res.textContent='Password too short (min 6).'; return; }

  try {
    const r = await fetch('../api/user.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ action: 'change_password', current: cur, new_password: nw })
    });
    const json = await r.json();
    if (json.success) {
      res.style.color = 'var(--success)';
      res.textContent = '✅ Password updated!';
      document.getElementById('pw-current').value = '';
      document.getElementById('pw-new').value = '';
      document.getElementById('pw-confirm').value = '';
    } else {
      res.style.color = 'var(--error)';
      res.textContent = '❌ ' + (json.error || 'Failed');
    }
  } catch(e) { res.style.color='var(--error)'; res.textContent='Network error.'; }
}

// ─── Canvas Management ────────────────────────────────
async function createCollabCanvas() {
  const name = document.getElementById('new-canvas-name').value.trim();
  if (!name) return showToast('Please enter a canvas name');

  const res = await fetch('../api/canvas.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ action: 'create', name, type: 'collaborative' })
  });
  const json = await res.json();
  if (json.success) {
    showToast('Canvas created!');
    setTimeout(() => window.location.href = '?canvas=' + json.canvas_id, 800);
  } else {
    showToast('Error: ' + (json.error || 'Failed'));
  }
}

async function sendInvite() {
  const username = document.getElementById('invite-username').value.trim();
  const result   = document.getElementById('invite-result');
  if (!username) return;

  const res = await fetch('../api/canvas.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ action: 'invite', canvas_id: STATE.canvasId, username })
  });
  const json = await res.json();

  if (json.success) {
    result.style.color = 'var(--success)';
    result.textContent = '✅ Invite sent to ' + username;
    document.getElementById('invite-username').value = '';
  } else {
    result.style.color = 'var(--error)';
    result.textContent = '❌ ' + (json.error || 'Failed');
  }
}

async function respondInvite(inviteId, status) {
  const res = await fetch('../api/canvas.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ action: 'respond_invite', invite_id: inviteId, status })
  });
  const json = await res.json();
  if (json.success) {
    showToast(status === 'accepted' ? '✅ Joined canvas!' : 'Invite declined');
    setTimeout(() => window.location.reload(), 800);
  }
}

// ─── Modal Helpers ────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close on backdrop click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ─── Toast ───────────────────────────────────────────
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

// ─── Resize Observer ─────────────────────────────────
new ResizeObserver(resizeCanvas).observe(container);

// ─── Boot ─────────────────────────────────────────────
initCanvas();
setTool('pen');
</script>
</body>
</html>
