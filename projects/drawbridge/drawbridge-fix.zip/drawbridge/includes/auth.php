<?php
// DrawBridge Canvas - Auth Helper

function dbc_session_start() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_strict_mode', 1);
        session_start();
    }
}

function dbc_is_logged_in() {
    dbc_session_start();
    return isset($_SESSION['dbc_user_id']) && isset($_SESSION['dbc_token']);
}

function dbc_require_login() {
    if (!dbc_is_logged_in()) {
        header('Location: ' . dbc_app_url('auth/login.php'));
        exit;
    }
}

function dbc_require_admin() {
    dbc_require_login();
    if ($_SESSION['dbc_role'] !== 'admin') {
        header('Location: ' . dbc_app_url('canvas/index.php'));
        exit;
    }
}

function dbc_app_url($path) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    // Walk up the directory tree to find the app root
    // The app root is 1 or 2 levels up depending on where we are
    $parts = explode('/', trim($script, '/'));
    // Remove filename
    array_pop($parts);
    // Remove one more level (e.g. 'auth', 'canvas', 'admin', 'api')
    $known_dirs = ['auth', 'canvas', 'admin', 'api', 'setup'];
    if (in_array(end($parts), $known_dirs)) {
        array_pop($parts);
    }
    $app_root = '/' . implode('/', $parts);
    $app_root = rtrim($app_root, '/');
    return $protocol . '://' . $host . $app_root . '/' . ltrim($path, '/');
}

function dbc_current_user() {
    if (!dbc_is_logged_in()) return null;
    return [
        'id'       => $_SESSION['dbc_user_id'],
        'username' => $_SESSION['dbc_username'],
        'role'     => $_SESSION['dbc_role'],
    ];
}

function dbc_login_user($user) {
    dbc_session_start();
    session_regenerate_id(true);
    $_SESSION['dbc_user_id']  = $user['id'];
    $_SESSION['dbc_username'] = $user['username'];
    $_SESSION['dbc_role']     = $user['role'];
    $_SESSION['dbc_token']    = bin2hex(random_bytes(32));

    // Update last login
    $db = dbc_get_db();
    $stmt = $db->prepare("UPDATE dbc_users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user['id']]);

    // Track active session
    $stmt = $db->prepare("INSERT INTO dbc_active_sessions (user_id, session_token, last_seen) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE last_seen = NOW()");
    $stmt->execute([$user['id'], $_SESSION['dbc_token']]);
}

function dbc_logout() {
    dbc_session_start();
    if (isset($_SESSION['dbc_token'])) {
        try {
            $db = dbc_get_db();
            $stmt = $db->prepare("DELETE FROM dbc_active_sessions WHERE session_token = ?");
            $stmt->execute([$_SESSION['dbc_token']]);
        } catch (Exception $e) {}
    }
    session_destroy();
}

function dbc_base_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    // Walk up to find root
    $root = defined('APP_URL') && APP_URL ? APP_URL : $protocol . '://' . $host;
    return $root;
}

function dbc_hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

function dbc_verify_password($password, $hash) {
    return password_verify($password, $hash);
}
