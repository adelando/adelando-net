# DrawBridge Canvas 🌉

A self-hosted collaborative whiteboard platform built with PHP + MySQL.

## Quick Start

### 1. Upload Files
Upload the entire `drawbridge/` folder to your web server (public_html or a subdirectory).

### 2. Create Database in cPanel
1. Log in to cPanel
2. Go to **MySQL Databases**
3. Create a new database (e.g. `mysite_drawbridge`)
4. Create a new user (e.g. `mysite_dbuser`) with a strong password
5. Add the user to the database with **All Privileges**

### 3. Run Setup Wizard
Visit your domain in a browser:
- `https://yourdomain.com/` (if uploaded to root)
- `https://yourdomain.com/drawbridge/` (if uploaded to subfolder)

The setup wizard will guide you through:
1. Database connection & initialization
2. Admin account creation
3. Branding (app name + logo)
4. Creating initial users

### 4. Done!
Log in with your admin credentials and start drawing!

---

## File Structure

```
drawbridge/
├── index.php              # Entry point / router
├── config.php             # Auto-generated config (DO NOT edit manually)
├── .htaccess              # Security rules
├── setup/
│   ├── index.php          # Setup wizard UI
│   └── setup_ajax.php     # Setup wizard backend
├── auth/
│   ├── login.php          # Login page
│   └── logout.php         # Logout handler
├── canvas/
│   └── index.php          # Main whiteboard
├── admin/
│   └── index.php          # Admin panel
├── api/
│   ├── canvas.php         # Canvas CRUD + invites
│   ├── sync.php           # Real-time sync (long polling)
│   ├── user.php           # User self-service
│   └── admin.php          # Admin operations
├── includes/
│   ├── bootstrap.php      # App init
│   ├── db.php             # Database helpers
│   └── auth.php           # Auth helpers
└── assets/
    ├── uploads/
    │   ├── logos/         # App logos
    │   ├── backgrounds/   # Canvas backgrounds
    │   └── images/        # Canvas images
    └── (css/js as needed)
```

## Requirements
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.3+
- Apache with mod_rewrite (standard on cPanel)

## Features
- ✏️ Drawing with pen, eraser, size & colour control
- ✋ Grab tool for panning
- 📝 Sticky notes
- 🖼️ Image upload on canvas
- T Text boxes
- ↩️ Undo / Redo
- 🔒 Personal canvases per user
- 👥 Collaborative canvases with invites
- 🔄 Real-time sync via long polling
- 🎨 Background colour & image
- 🌗 Light / dark mode
- 👑 Full admin panel
- 🗄️ Database management from admin panel
- 🔑 Password management
- 📋 First-run setup wizard

## Security Notes
- config.php is protected by .htaccess
- All API endpoints verify session authentication
- Passwords hashed with bcrypt (cost 12)
- Admin routes are protected by role check
- SQL injection prevented via PDO prepared statements
