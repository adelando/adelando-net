<?php
// DrawBridge Canvas - Database Helper

function dbc_db_connect($host = null, $name = null, $user = null, $pass = null) {
    $host = $host ?? DB_HOST;
    $name = $name ?? DB_NAME;
    $user = $user ?? DB_USER;
    $pass = $pass ?? DB_PASS;

    try {
        $pdo = new PDO(
            "mysql:host={$host};dbname={$name};charset=utf8mb4",
            $user,
            $pass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        return null;
    }
}

function dbc_get_db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = dbc_db_connect();
        if (!$pdo) {
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

function dbc_get_setting($key, $default = null) {
    try {
        $db = dbc_get_db();
        $stmt = $db->prepare("SELECT setting_value FROM dbc_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

function dbc_set_setting($key, $value) {
    $db = dbc_get_db();
    $stmt = $db->prepare("INSERT INTO dbc_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    return $stmt->execute([$key, $value, $value]);
}
