<?php
// DrawBridge Canvas - Entry Point

$config = __DIR__ . '/config.php';

if (!file_exists($config)) {
    header('Location: setup/index.php');
    exit;
}

require_once $config;

if (!defined('DBC_INSTALLED') || !DBC_INSTALLED) {
    header('Location: setup/index.php');
    exit;
}

require_once __DIR__ . '/includes/auth.php';

if (dbc_is_logged_in()) {
    header('Location: canvas/index.php');
} else {
    header('Location: auth/login.php');
}
exit;
