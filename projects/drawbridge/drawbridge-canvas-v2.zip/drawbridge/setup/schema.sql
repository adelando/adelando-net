-- DrawBridge Canvas Database Schema
-- Auto-generated during setup wizard

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- App Settings
CREATE TABLE IF NOT EXISTS `dbc_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Users
CREATE TABLE IF NOT EXISTS `dbc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `avatar_color` varchar(7) NOT NULL DEFAULT '#4f86f7',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Canvases
CREATE TABLE IF NOT EXISTS `dbc_canvases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT 'My Canvas',
  `type` enum('personal','collaborative') NOT NULL DEFAULT 'personal',
  `background_color` varchar(7) NOT NULL DEFAULT '#ffffff',
  `background_image` varchar(255) DEFAULT NULL,
  `canvas_data` longtext DEFAULT NULL,
  `thumbnail` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `fk_canvas_owner` FOREIGN KEY (`owner_id`) REFERENCES `dbc_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Canvas Members (for collaborative canvases)
CREATE TABLE IF NOT EXISTS `dbc_canvas_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canvas_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` enum('owner','editor','viewer') NOT NULL DEFAULT 'editor',
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `canvas_user` (`canvas_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_member_canvas` FOREIGN KEY (`canvas_id`) REFERENCES `dbc_canvases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_member_user` FOREIGN KEY (`user_id`) REFERENCES `dbc_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Canvas Invites
CREATE TABLE IF NOT EXISTS `dbc_canvas_invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canvas_id` int(11) NOT NULL,
  `invited_by` int(11) NOT NULL,
  `invited_user_id` int(11) NOT NULL,
  `invite_code` varchar(64) NOT NULL,
  `status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invite_code` (`invite_code`),
  KEY `canvas_id` (`canvas_id`),
  KEY `invited_user_id` (`invited_user_id`),
  CONSTRAINT `fk_invite_canvas` FOREIGN KEY (`canvas_id`) REFERENCES `dbc_canvases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invite_user` FOREIGN KEY (`invited_user_id`) REFERENCES `dbc_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Canvas Strokes (real-time sync via long polling)
CREATE TABLE IF NOT EXISTS `dbc_canvas_strokes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `canvas_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stroke_data` longtext NOT NULL,
  `action` enum('draw','erase','add_image','add_note','add_text','move','delete','clear') NOT NULL DEFAULT 'draw',
  `created_at` timestamp(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `canvas_id` (`canvas_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sticky Notes
CREATE TABLE IF NOT EXISTS `dbc_sticky_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canvas_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text DEFAULT NULL,
  `color` varchar(7) NOT NULL DEFAULT '#fef08a',
  `pos_x` float NOT NULL DEFAULT 100,
  `pos_y` float NOT NULL DEFAULT 100,
  `width` int(11) NOT NULL DEFAULT 200,
  `height` int(11) NOT NULL DEFAULT 200,
  `z_index` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `canvas_id` (`canvas_id`),
  CONSTRAINT `fk_note_canvas` FOREIGN KEY (`canvas_id`) REFERENCES `dbc_canvases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Uploaded Images on canvas
CREATE TABLE IF NOT EXISTS `dbc_canvas_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canvas_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `pos_x` float NOT NULL DEFAULT 100,
  `pos_y` float NOT NULL DEFAULT 100,
  `width` int(11) NOT NULL DEFAULT 300,
  `height` int(11) NOT NULL DEFAULT 200,
  `z_index` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `canvas_id` (`canvas_id`),
  CONSTRAINT `fk_image_canvas` FOREIGN KEY (`canvas_id`) REFERENCES `dbc_canvases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sessions tracking (for multi-user awareness)
CREATE TABLE IF NOT EXISTS `dbc_active_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `canvas_id` int(11) DEFAULT NULL,
  `session_token` varchar(128) NOT NULL,
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cursor_x` float DEFAULT NULL,
  `cursor_y` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `canvas_id` (`canvas_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
