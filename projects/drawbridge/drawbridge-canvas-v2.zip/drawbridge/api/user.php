<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_login();
header('Content-Type: application/json');

$user  = dbc_current_user();
$db    = dbc_get_db();
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

switch ($action) {
    case 'change_password': handle_change_password(); break;
    default: echo json_encode(['error' => 'Unknown action']);
}

function handle_change_password() {
    global $db, $user, $input;
    $current  = $input['current'] ?? '';
    $new_pass = $input['new_password'] ?? '';

    if (!$current || !$new_pass) { echo json_encode(['error' => 'All fields required']); return; }
    if (strlen($new_pass) < 6) { echo json_encode(['error' => 'Password too short (min 6)']); return; }

    $stmt = $db->prepare("SELECT password FROM dbc_users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch();

    if (!$row || !dbc_verify_password($current, $row['password'])) {
        echo json_encode(['error' => 'Current password is incorrect']);
        return;
    }

    $hash = dbc_hash_password($new_pass);
    $stmt = $db->prepare("UPDATE dbc_users SET password = ? WHERE id = ?");
    $stmt->execute([$hash, $user['id']]);

    echo json_encode(['success' => true]);
}
