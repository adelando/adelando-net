<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_admin();
header('Content-Type: application/json');

$user  = dbc_current_user();
$db    = dbc_get_db();
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

switch ($action) {
    case 'add_user':          handle_add_user();         break;
    case 'rename_user':       handle_rename_user();      break;
    case 'reset_password':    handle_reset_password();   break;
    case 'toggle_user':       handle_toggle_user();      break;
    case 'get_user_canvases': handle_get_canvases();     break;
    case 'delete_canvas':     handle_delete_canvas();    break;
    case 'save_app_settings': handle_save_app_settings();break;
    case 'test_db':           handle_test_db();          break;
    case 'save_db':           handle_save_db();          break;
    default: echo json_encode(['error' => 'Unknown action']);
}

function handle_add_user() {
    global $db, $input;
    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';
    $role     = in_array($input['role'] ?? 'user', ['user','admin']) ? $input['role'] : 'user';

    if (!$username || strlen($username) < 2) { echo json_encode(['error' => 'Username too short']); return; }
    if (!$password || strlen($password) < 4) { echo json_encode(['error' => 'Password too short']); return; }

    // Check unique
    $stmt = $db->prepare("SELECT id FROM dbc_users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) { echo json_encode(['error' => 'Username already exists']); return; }

    $hash = dbc_hash_password($password);
    $stmt = $db->prepare("INSERT INTO dbc_users (username, password, role) VALUES (?, ?, ?)");
    $stmt->execute([$username, $hash, $role]);
    $uid = $db->lastInsertId();

    // Create personal canvas
    $stmt = $db->prepare("INSERT INTO dbc_canvases (owner_id, name, type) VALUES (?, 'My Canvas', 'personal')");
    $stmt->execute([$uid]);

    echo json_encode(['success' => true, 'user_id' => $uid]);
}

function handle_rename_user() {
    global $db, $input, $user;
    $user_id  = (int)($input['user_id'] ?? 0);
    $username = trim($input['username'] ?? '');

    if (!$user_id || strlen($username) < 2) { echo json_encode(['error' => 'Invalid data']); return; }

    // Check unique
    $stmt = $db->prepare("SELECT id FROM dbc_users WHERE username = ? AND id != ?");
    $stmt->execute([$username, $user_id]);
    if ($stmt->fetch()) { echo json_encode(['error' => 'Username already taken']); return; }

    $stmt = $db->prepare("UPDATE dbc_users SET username = ? WHERE id = ?");
    $stmt->execute([$username, $user_id]);
    echo json_encode(['success' => true]);
}

function handle_reset_password() {
    global $db, $input;
    $user_id  = (int)($input['user_id'] ?? 0);
    $password = $input['password'] ?? '';

    if (!$user_id || strlen($password) < 6) { echo json_encode(['error' => 'Invalid data']); return; }

    $hash = dbc_hash_password($password);
    $stmt = $db->prepare("UPDATE dbc_users SET password = ? WHERE id = ?");
    $stmt->execute([$hash, $user_id]);
    echo json_encode(['success' => true]);
}

function handle_toggle_user() {
    global $db, $input, $user;
    $user_id = (int)($input['user_id'] ?? 0);
    if (!$user_id || $user_id === $user['id']) { echo json_encode(['error' => 'Invalid']); return; }

    $stmt = $db->prepare("UPDATE dbc_users SET is_active = NOT is_active WHERE id = ? AND role != 'admin'");
    $stmt->execute([$user_id]);
    echo json_encode(['success' => true]);
}

function handle_get_canvases() {
    global $db, $input;
    $user_id = (int)($input['user_id'] ?? 0);
    if (!$user_id) { echo json_encode(['error' => 'Invalid']); return; }

    $stmt = $db->prepare("SELECT id, name, type, thumbnail, updated_at FROM dbc_canvases WHERE owner_id = ? AND is_active = 1 ORDER BY updated_at DESC");
    $stmt->execute([$user_id]);
    $canvases = $stmt->fetchAll();

    echo json_encode(['success' => true, 'canvases' => $canvases]);
}

function handle_delete_canvas() {
    global $db, $input;
    $canvas_id = (int)($input['canvas_id'] ?? 0);
    if (!$canvas_id) { echo json_encode(['error' => 'Invalid']); return; }

    $stmt = $db->prepare("UPDATE dbc_canvases SET is_active = 0 WHERE id = ?");
    $stmt->execute([$canvas_id]);
    echo json_encode(['success' => true]);
}

function handle_save_app_settings() {
    global $db, $input;
    $app_name = trim($input['app_name'] ?? '');
    $logo     = $input['logo'] ?? null;

    if ($app_name) {
        dbc_set_setting('app_name', $app_name);

        // Update config
        $config = file_get_contents(APP_PATH . '/config.php');
        $config = preg_replace(
            "/define\('APP_NAME',\s*'[^']*'\);/",
            "define('APP_NAME', '" . addslashes($app_name) . "');",
            $config
        );
        file_put_contents(APP_PATH . '/config.php', $config);
    }

    if ($logo && strpos($logo, 'data:') === 0) {
        $logo_path = save_logo($logo);
        if ($logo_path) {
            dbc_set_setting('app_logo', $logo_path);
        }
    }

    echo json_encode(['success' => true]);
}

function handle_test_db() {
    global $input;
    $host = trim($input['host'] ?? '');
    $name = trim($input['name'] ?? '');
    $user = trim($input['user'] ?? '');
    $pass = $input['pass'] ?? '';

    try {
        new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        $msg = preg_replace('/\[.*?\]/', '', $e->getMessage());
        echo json_encode(['success' => false, 'error' => trim($msg)]);
    }
}

function handle_save_db() {
    global $input;
    $host = trim($input['host'] ?? '');
    $name = trim($input['name'] ?? '');
    $user = trim($input['user'] ?? '');
    $pass = $input['pass'] ?? '';

    // Test first
    try {
        new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Connection test failed: ' . preg_replace('/\[.*?\]/', '', $e->getMessage())]);
        return;
    }

    $config = file_get_contents(APP_PATH . '/config.php');

    $config = preg_replace("/define\('DB_HOST',\s*'[^']*'\);/", "define('DB_HOST', '" . addslashes($host) . "');", $config);
    $config = preg_replace("/define\('DB_NAME',\s*'[^']*'\);/", "define('DB_NAME', '" . addslashes($name) . "');", $config);
    $config = preg_replace("/define\('DB_USER',\s*'[^']*'\);/", "define('DB_USER', '" . addslashes($user) . "');", $config);

    // Only update password if provided
    if ($pass) {
        $config = preg_replace("/define\('DB_PASS',\s*'[^']*'\);/", "define('DB_PASS', '" . addslashes($pass) . "');", $config);
    }

    if (file_put_contents(APP_PATH . '/config.php', $config) === false) {
        echo json_encode(['success' => false, 'error' => 'Could not write config file']);
        return;
    }

    echo json_encode(['success' => true]);
}

function save_logo($data_url) {
    preg_match('/^data:(image\/[\w+]+);base64,/', $data_url, $m);
    if (!$m) return null;
    $ext_map = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','image/svg+xml'=>'svg'];
    $ext = $ext_map[$m[1]] ?? 'png';
    $data = base64_decode(substr($data_url, strpos($data_url, ',') + 1));
    if (!$data) return null;
    $dir = APP_PATH . '/assets/uploads/logos/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $filename = 'logo_' . time() . '.' . $ext;
    file_put_contents($dir . $filename, $data);
    return 'assets/uploads/logos/' . $filename;
}
