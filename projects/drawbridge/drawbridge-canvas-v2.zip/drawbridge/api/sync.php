<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_login();
header('Content-Type: application/json');

$user = dbc_current_user();
$db   = dbc_get_db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input  = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $input['action'] ?? 'push_stroke';

    if ($action === 'heartbeat') {
        handle_heartbeat($input);
    } else {
        handle_push($input);
    }
} else {
    handle_poll();
}

// ─── Poll for new strokes ─────────────────────────────
function handle_poll() {
    global $db, $user;
    $canvas_id = (int)($_GET['canvas_id'] ?? 0);
    $since_id  = (int)($_GET['since'] ?? 0);

    if (!$canvas_id || !can_access_canvas($canvas_id)) {
        echo json_encode(['strokes' => [], 'users' => []]);
        return;
    }

    // Get new strokes since last poll
    $stmt = $db->prepare("
        SELECT s.id, s.user_id, s.stroke_data, s.action, s.created_at
        FROM dbc_canvas_strokes s
        WHERE s.canvas_id = ? AND s.id > ?
        ORDER BY s.id ASC
        LIMIT 100
    ");
    $stmt->execute([$canvas_id, $since_id]);
    $strokes = $stmt->fetchAll();

    // Get active users on this canvas
    $stmt = $db->prepare("
        SELECT u.id, u.username, u.avatar_color as color
        FROM dbc_active_sessions s
        JOIN dbc_users u ON u.id = s.user_id
        WHERE s.canvas_id = ? AND s.last_seen > DATE_SUB(NOW(), INTERVAL 30 SECOND)
    ");
    $stmt->execute([$canvas_id]);
    $active_users = $stmt->fetchAll();

    // Purge old strokes (keep last 10000)
    $stmt = $db->prepare("
        DELETE FROM dbc_canvas_strokes 
        WHERE canvas_id = ? AND id < (
            SELECT min_id FROM (
                SELECT MIN(id) as min_id FROM (
                    SELECT id FROM dbc_canvas_strokes WHERE canvas_id = ? ORDER BY id DESC LIMIT 10000
                ) t
            ) t2
        )
    ");
    $stmt->execute([$canvas_id, $canvas_id]);

    echo json_encode(['strokes' => $strokes, 'users' => $active_users]);
}

// ─── Push a new stroke ────────────────────────────────
function handle_push($input) {
    global $db, $user;
    $canvas_id   = (int)($input['canvas_id'] ?? 0);
    $stroke_data = $input['stroke_data'] ?? '';
    $action      = $input['action'] ?? 'draw';

    if (!$canvas_id || !$stroke_data || !can_access_canvas($canvas_id)) {
        echo json_encode(['success' => false]);
        return;
    }

    $allowed_actions = ['draw','erase','add_image','add_note','add_text','move','delete','clear'];
    if (!in_array($action, $allowed_actions)) $action = 'draw';

    $stmt = $db->prepare("INSERT INTO dbc_canvas_strokes (canvas_id, user_id, stroke_data, action) VALUES (?, ?, ?, ?)");
    $stmt->execute([$canvas_id, $user['id'], $stroke_data, $action]);

    echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
}

// ─── Heartbeat ────────────────────────────────────────
function handle_heartbeat($input) {
    global $db, $user;
    $canvas_id = (int)($input['canvas_id'] ?? 0);
    if (!$canvas_id) { echo json_encode(['success' => false]); return; }

    $token = $_SESSION['dbc_token'] ?? '';

    $stmt = $db->prepare("
        INSERT INTO dbc_active_sessions (user_id, canvas_id, session_token, last_seen)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE canvas_id = ?, last_seen = NOW()
    ");
    $stmt->execute([$user['id'], $canvas_id, $token, $canvas_id]);

    echo json_encode(['success' => true]);
}

// ─── Access Check ─────────────────────────────────────
function can_access_canvas($canvas_id) {
    global $db, $user;
    if ($user['role'] === 'admin') return true;

    $stmt = $db->prepare("
        SELECT c.id FROM dbc_canvases c
        WHERE c.id = ? AND c.is_active = 1 AND (
            c.owner_id = ?
            OR EXISTS (SELECT 1 FROM dbc_canvas_members m WHERE m.canvas_id = c.id AND m.user_id = ?)
        )
    ");
    $stmt->execute([$canvas_id, $user['id'], $user['id']]);
    return (bool)$stmt->fetch();
}
