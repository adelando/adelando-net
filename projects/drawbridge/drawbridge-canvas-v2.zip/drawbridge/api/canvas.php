<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_login();
header('Content-Type: application/json');

$user = dbc_current_user();
$db   = dbc_get_db();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$input  = [];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $input['action'] ?? $action;
}

switch ($action) {
    case 'load':   handle_load();   break;
    case 'save':   handle_save();   break;
    case 'create': handle_create(); break;
    case 'invite': handle_invite(); break;
    case 'respond_invite': handle_respond_invite(); break;
    case 'update_setting': handle_update_setting(); break;
    default: echo json_encode(['error' => 'Unknown action']); exit;
}

// ─── Load Canvas ─────────────────────────────────────
function handle_load() {
    global $db, $user, $input;
    $canvas_id = (int)($_GET['canvas_id'] ?? $input['canvas_id'] ?? 0);
    if (!$canvas_id) { echo json_encode(['error' => 'No canvas ID']); return; }

    if (!can_access_canvas($canvas_id)) {
        echo json_encode(['error' => 'Access denied']); return;
    }

    $stmt = $db->prepare("SELECT canvas_data, background_color, background_image FROM dbc_canvases WHERE id = ?");
    $stmt->execute([$canvas_id]);
    $row = $stmt->fetch();

    if (!$row) { echo json_encode(['error' => 'Canvas not found']); return; }

    $data = $row['canvas_data'] ? json_decode($row['canvas_data'], true) : null;
    if ($data && $row['background_color']) $data['bgColor'] = $row['background_color'];

    echo json_encode(['success' => true, 'data' => $data]);
}

// ─── Save Canvas ──────────────────────────────────────
function handle_save() {
    global $db, $user, $input;
    $canvas_id = (int)($input['canvas_id'] ?? 0);
    $data      = $input['data'] ?? null;

    if (!$canvas_id || !$data) { echo json_encode(['error' => 'Missing data']); return; }
    if (!can_access_canvas($canvas_id)) { echo json_encode(['error' => 'Access denied']); return; }

    $json = json_encode($data);

    // Generate thumbnail from dataUrl if present
    $thumbnail = null;
    if (!empty($data['canvasDataUrl'])) {
        $thumbnail = $data['canvasDataUrl'];
    }

    $stmt = $db->prepare("UPDATE dbc_canvases SET canvas_data = ?, thumbnail = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$json, $thumbnail, $canvas_id]);

    echo json_encode(['success' => true]);
}

// ─── Create Canvas ────────────────────────────────────
function handle_create() {
    global $db, $user, $input;
    $name = trim($input['name'] ?? 'New Canvas');
    $type = $input['type'] ?? 'collaborative';
    if (!in_array($type, ['personal','collaborative'])) $type = 'collaborative';

    $stmt = $db->prepare("INSERT INTO dbc_canvases (owner_id, name, type) VALUES (?, ?, ?)");
    $stmt->execute([$user['id'], $name, $type]);
    $id = $db->lastInsertId();

    echo json_encode(['success' => true, 'canvas_id' => $id]);
}

// ─── Invite User ──────────────────────────────────────
function handle_invite() {
    global $db, $user, $input;
    $canvas_id = (int)($input['canvas_id'] ?? 0);
    $username  = trim($input['username'] ?? '');

    if (!$canvas_id || !$username) { echo json_encode(['error' => 'Missing data']); return; }

    // Check ownership
    $stmt = $db->prepare("SELECT id, type FROM dbc_canvases WHERE id = ? AND owner_id = ?");
    $stmt->execute([$canvas_id, $user['id']]);
    $canvas = $stmt->fetch();
    if (!$canvas) { echo json_encode(['error' => 'Canvas not found or not yours']); return; }
    if ($canvas['type'] !== 'collaborative') { echo json_encode(['error' => 'Canvas is not collaborative']); return; }

    // Find invited user
    $stmt = $db->prepare("SELECT id FROM dbc_users WHERE username = ? AND is_active = 1");
    $stmt->execute([$username]);
    $invited = $stmt->fetch();
    if (!$invited) { echo json_encode(['error' => 'User not found']); return; }
    if ($invited['id'] === $user['id']) { echo json_encode(['error' => 'Cannot invite yourself']); return; }

    // Check if already member
    $stmt = $db->prepare("SELECT id FROM dbc_canvas_members WHERE canvas_id = ? AND user_id = ?");
    $stmt->execute([$canvas_id, $invited['id']]);
    if ($stmt->fetch()) { echo json_encode(['error' => 'User is already a member']); return; }

    // Check for existing pending invite
    $stmt = $db->prepare("SELECT id FROM dbc_canvas_invites WHERE canvas_id = ? AND invited_user_id = ? AND status = 'pending'");
    $stmt->execute([$canvas_id, $invited['id']]);
    if ($stmt->fetch()) { echo json_encode(['error' => 'Invite already pending']); return; }

    $code = bin2hex(random_bytes(16));
    $stmt = $db->prepare("INSERT INTO dbc_canvas_invites (canvas_id, invited_by, invited_user_id, invite_code, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))");
    $stmt->execute([$canvas_id, $user['id'], $invited['id'], $code]);

    echo json_encode(['success' => true]);
}

// ─── Respond to Invite ────────────────────────────────
function handle_respond_invite() {
    global $db, $user, $input;
    $invite_id = (int)($input['invite_id'] ?? 0);
    $status    = $input['status'] ?? '';

    if (!in_array($status, ['accepted','declined'])) { echo json_encode(['error' => 'Invalid status']); return; }

    $stmt = $db->prepare("SELECT * FROM dbc_canvas_invites WHERE id = ? AND invited_user_id = ? AND status = 'pending'");
    $stmt->execute([$invite_id, $user['id']]);
    $invite = $stmt->fetch();
    if (!$invite) { echo json_encode(['error' => 'Invite not found']); return; }

    $stmt = $db->prepare("UPDATE dbc_canvas_invites SET status = ? WHERE id = ?");
    $stmt->execute([$status, $invite_id]);

    if ($status === 'accepted') {
        $stmt = $db->prepare("INSERT IGNORE INTO dbc_canvas_members (canvas_id, user_id, role) VALUES (?, ?, 'editor')");
        $stmt->execute([$invite['canvas_id'], $user['id']]);
    }

    echo json_encode(['success' => true, 'canvas_id' => $invite['canvas_id']]);
}

// ─── Update Setting ───────────────────────────────────
function handle_update_setting() {
    global $db, $user, $input;
    $canvas_id = (int)($input['canvas_id'] ?? 0);
    $key       = $input['key'] ?? '';
    $value     = $input['value'] ?? '';

    $allowed_keys = ['background_color', 'background_image', 'name'];
    if (!in_array($key, $allowed_keys)) { echo json_encode(['error' => 'Invalid key']); return; }
    if (!can_access_canvas($canvas_id)) { echo json_encode(['error' => 'Access denied']); return; }

    $stmt = $db->prepare("UPDATE dbc_canvases SET {$key} = ? WHERE id = ?");
    $stmt->execute([$value, $canvas_id]);

    echo json_encode(['success' => true]);
}

// ─── Access Check ─────────────────────────────────────
function can_access_canvas($canvas_id) {
    global $db, $user;
    if ($user['role'] === 'admin') return true;

    $stmt = $db->prepare("
        SELECT c.id FROM dbc_canvases c
        WHERE c.id = ? AND c.is_active = 1 AND (
            c.owner_id = ?
            OR EXISTS (SELECT 1 FROM dbc_canvas_members m WHERE m.canvas_id = c.id AND m.user_id = ?)
        )
    ");
    $stmt->execute([$canvas_id, $user['id'], $user['id']]);
    return (bool)$stmt->fetch();
}
