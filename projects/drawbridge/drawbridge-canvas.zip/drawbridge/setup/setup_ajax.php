<?php
// DrawBridge Canvas - Setup AJAX Handler
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Block if already installed
$root = dirname(__FILE__, 2);
$config_file = $root . '/config.php';
if (file_exists($config_file)) {
    require_once $config_file;
    if (defined('DBC_INSTALLED') && DBC_INSTALLED) {
        echo json_encode(['error' => 'Already installed']);
        exit;
    }
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['error' => 'Invalid input']);
    exit;
}

$action = $input['action'] ?? '';

switch ($action) {
    case 'test':
        handle_test($input);
        break;
    case 'init':
        handle_init($input);
        break;
    case 'finish':
        handle_finish($input);
        break;
    default:
        echo json_encode(['error' => 'Unknown action']);
}

// ─── Test Connection ───────────────────────────────────
function handle_test($input) {
    $host = trim($input['host'] ?? '');
    $name = trim($input['name'] ?? '');
    $user = trim($input['user'] ?? '');
    $pass = $input['pass'] ?? '';

    if (!$host || !$name || !$user) {
        echo json_encode(['success' => false, 'error' => 'All fields are required']);
        return;
    }

    try {
        $pdo = new PDO(
            "mysql:host={$host};dbname={$name};charset=utf8mb4",
            $user, $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        // Strip sensitive info from error
        $msg = preg_replace('/\[.*?\]/', '', $msg);
        echo json_encode(['success' => false, 'error' => trim($msg)]);
    }
}

// ─── Initialize Database ───────────────────────────────
function handle_init($input) {
    $host = trim($input['host'] ?? '');
    $name = trim($input['name'] ?? '');
    $user = trim($input['user'] ?? '');
    $pass = $input['pass'] ?? '';

    try {
        $pdo = new PDO(
            "mysql:host={$host};dbname={$name};charset=utf8mb4",
            $user, $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        // Read schema
        $schema = file_get_contents(__DIR__ . '/schema.sql');
        if (!$schema) {
            echo json_encode(['success' => false, 'error' => 'Schema file not found']);
            return;
        }

        // Execute each statement
        $statements = array_filter(array_map('trim', explode(';', $schema)));
        foreach ($statements as $stmt) {
            if ($stmt) {
                $pdo->exec($stmt);
            }
        }

        // Save DB config to session for finish step
        session_start();
        $_SESSION['dbc_setup'] = [
            'host' => $host,
            'name' => $name,
            'user' => $user,
            'pass' => $pass,
        ];

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        $msg = preg_replace('/\[.*?\]/', '', $msg);
        echo json_encode(['success' => false, 'error' => trim($msg)]);
    }
}

// ─── Finish Setup ──────────────────────────────────────
function handle_finish($input) {
    session_start();

    if (!isset($_SESSION['dbc_setup'])) {
        echo json_encode(['success' => false, 'error' => 'Session expired. Please restart setup.']);
        return;
    }

    $db_conf = $_SESSION['dbc_setup'];
    $admin_user = trim($input['admin_user'] ?? '');
    $admin_pass = $input['admin_pass'] ?? '';
    $app_name   = trim($input['app_name'] ?? 'DrawBridge Canvas');
    $logo_data  = $input['logo'] ?? null;
    $users      = $input['users'] ?? [];

    // Validate
    if (!$admin_user || strlen($admin_user) < 3) {
        echo json_encode(['success' => false, 'error' => 'Invalid admin username']);
        return;
    }
    if (!$admin_pass || strlen($admin_pass) < 6) {
        echo json_encode(['success' => false, 'error' => 'Admin password too short']);
        return;
    }

    try {
        $pdo = new PDO(
            "mysql:host={$db_conf['host']};dbname={$db_conf['name']};charset=utf8mb4",
            $db_conf['user'], $db_conf['pass'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        // Create admin user
        $hash = password_hash($admin_pass, PASSWORD_BCRYPT, ['cost' => 12]);
        $stmt = $pdo->prepare("INSERT INTO dbc_users (username, password, role) VALUES (?, ?, 'admin')");
        $stmt->execute([$admin_user, $hash]);
        $admin_id = $pdo->lastInsertId();

        // Create admin personal canvas
        $stmt = $pdo->prepare("INSERT INTO dbc_canvases (owner_id, name, type) VALUES (?, 'My Canvas', 'personal')");
        $stmt->execute([$admin_id]);

        // Save app settings
        $settings = [
            'app_name'        => $app_name,
            'setup_complete'  => '1',
            'setup_date'      => date('Y-m-d H:i:s'),
        ];

        // Handle logo upload
        if ($logo_data && strpos($logo_data, 'data:') === 0) {
            $logo_path = save_logo($logo_data, $root = dirname(__FILE__, 2));
            if ($logo_path) {
                $settings['app_logo'] = $logo_path;
            }
        }

        $stmt = $pdo->prepare("INSERT INTO dbc_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        foreach ($settings as $k => $v) {
            $stmt->execute([$k, $v, $v]);
        }

        // Create general users
        foreach ($users as $u) {
            $uname = trim($u['name'] ?? '');
            $upass = $u['pass'] ?? '';
            if (!$uname || !$upass) continue;

            $uhash = password_hash($upass, PASSWORD_BCRYPT, ['cost' => 12]);
            $ustmt = $pdo->prepare("INSERT IGNORE INTO dbc_users (username, password, role) VALUES (?, ?, 'user')");
            $ustmt->execute([$uname, $uhash]);
            $uid = $pdo->lastInsertId();

            if ($uid) {
                $cstmt = $pdo->prepare("INSERT INTO dbc_canvases (owner_id, name, type) VALUES (?, 'My Canvas', 'personal')");
                $cstmt->execute([$uid]);
            }
        }

        // Write config file
        write_config($db_conf, $app_name);

        unset($_SESSION['dbc_setup']);
        echo json_encode(['success' => true]);

    } catch (PDOException $e) {
        $msg = $e->getMessage();
        $msg = preg_replace('/\[.*?\]/', '', $msg);
        echo json_encode(['success' => false, 'error' => trim($msg)]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

// ─── Helpers ───────────────────────────────────────────
function save_logo($data_url, $root) {
    preg_match('/^data:(image\/\w+);base64,/', $data_url, $matches);
    if (!$matches) return null;

    $mime = $matches[1];
    $ext_map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'image/svg+xml' => 'svg'];
    $ext = $ext_map[$mime] ?? 'png';

    $data = base64_decode(substr($data_url, strpos($data_url, ',') + 1));
    if (!$data) return null;

    $dir = $root . '/assets/uploads/logos/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $filename = 'logo_' . time() . '.' . $ext;
    $filepath = $dir . $filename;

    if (file_put_contents($filepath, $data) === false) return null;
    return 'assets/uploads/logos/' . $filename;
}

function write_config($db, $app_name) {
    $root = dirname(__FILE__, 2);
    
    // Detect app URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $app_url = $protocol . '://' . $host;

    $app_name_safe = addslashes($app_name);
    $host_safe = addslashes($db['host']);
    $name_safe = addslashes($db['name']);
    $user_safe = addslashes($db['user']);
    $pass_safe = addslashes($db['pass']);
    $url_safe  = addslashes($app_url);

    $config = <<<PHP
<?php
// DrawBridge Canvas - Configuration File
// Auto-generated by setup wizard on {$_SERVER['REQUEST_TIME_FLOAT']}

define('DBC_INSTALLED', true);

// Database
define('DB_HOST', '{$host_safe}');
define('DB_NAME', '{$name_safe}');
define('DB_USER', '{$user_safe}');
define('DB_PASS', '{$pass_safe}');
define('DB_PREFIX', 'dbc_');

// App
define('APP_NAME', '{$app_name_safe}');
define('APP_VERSION', '1.0.0');
define('APP_URL', '{$url_safe}');
define('APP_PATH', __DIR__);

// Security
define('SESSION_LIFETIME', 86400);
define('POLL_INTERVAL', 2000);

// Uploads
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
PHP;

    file_put_contents($root . '/config.php', $config);
}
