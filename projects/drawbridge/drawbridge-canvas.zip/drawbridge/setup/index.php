<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DrawBridge Canvas — Setup</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0a0f;
    --surface: #13131a;
    --surface2: #1c1c28;
    --border: #2a2a3a;
    --accent: #5b6ef5;
    --accent2: #a78bfa;
    --success: #34d399;
    --error: #f87171;
    --warning: #fbbf24;
    --text: #e8e8f0;
    --text-muted: #7878a0;
    --radius: 12px;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow-x: hidden;
  }

  /* Animated background */
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background: 
      radial-gradient(ellipse 80% 50% at 20% 20%, rgba(91,110,245,0.12) 0%, transparent 60%),
      radial-gradient(ellipse 60% 60% at 80% 80%, rgba(167,139,250,0.08) 0%, transparent 60%);
    pointer-events: none;
    z-index: 0;
  }

  .setup-container {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 640px;
    margin: 40px auto;
    padding: 0 20px;
  }

  /* Logo / Header */
  .setup-header {
    text-align: center;
    margin-bottom: 40px;
  }

  .logo-mark {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
  }

  .logo-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    box-shadow: 0 0 30px rgba(91,110,245,0.4);
  }

  .logo-text {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    background: linear-gradient(135deg, #fff 0%, var(--accent2) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .setup-header p {
    color: var(--text-muted);
    font-size: 15px;
  }

  /* Progress Steps */
  .steps-nav {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0;
    margin-bottom: 36px;
  }

  .step-dot {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    position: relative;
  }

  .step-dot .dot {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: 2px solid var(--border);
    background: var(--surface);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-muted);
    transition: all 0.3s ease;
    z-index: 1;
    position: relative;
  }

  .step-dot.active .dot {
    border-color: var(--accent);
    background: var(--accent);
    color: white;
    box-shadow: 0 0 16px rgba(91,110,245,0.5);
  }

  .step-dot.done .dot {
    border-color: var(--success);
    background: var(--success);
    color: white;
  }

  .step-dot .label {
    font-size: 10px;
    color: var(--text-muted);
    white-space: nowrap;
    font-weight: 500;
  }

  .step-dot.active .label { color: var(--accent); }
  .step-dot.done .label { color: var(--success); }

  .step-line {
    flex: 1;
    height: 2px;
    background: var(--border);
    margin-bottom: 22px;
    max-width: 60px;
    transition: background 0.3s;
  }

  .step-line.done { background: var(--success); }

  /* Card */
  .setup-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 36px;
    box-shadow: 0 24px 80px rgba(0,0,0,0.5);
  }

  .step-panel { display: none; }
  .step-panel.active { display: block; }

  .step-title {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 700;
    margin-bottom: 6px;
  }

  .step-desc {
    color: var(--text-muted);
    font-size: 14px;
    margin-bottom: 28px;
    line-height: 1.6;
  }

  /* Form Elements */
  .form-group {
    margin-bottom: 20px;
  }

  .form-group label {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-muted);
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .form-group input[type="text"],
  .form-group input[type="password"],
  .form-group input[type="email"] {
    width: 100%;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 12px 16px;
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 15px;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }

  .form-group input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(91,110,245,0.15);
  }

  .form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }

  /* Buttons */
  .btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: var(--radius);
    font-family: 'DM Sans', sans-serif;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
  }

  .btn-primary {
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    color: white;
    box-shadow: 0 4px 20px rgba(91,110,245,0.35);
  }

  .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 28px rgba(91,110,245,0.45);
  }

  .btn-secondary {
    background: var(--surface2);
    color: var(--text);
    border: 1px solid var(--border);
  }

  .btn-secondary:hover { background: var(--border); }

  .btn-success {
    background: linear-gradient(135deg, #059669, var(--success));
    color: white;
  }

  .btn-ghost {
    background: transparent;
    color: var(--text-muted);
    padding: 12px 16px;
  }

  .btn-ghost:hover { color: var(--text); }

  .btn-full { width: 100%; justify-content: center; }

  .btn-actions {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-top: 28px;
    justify-content: space-between;
  }

  /* Alert boxes */
  .alert {
    padding: 14px 16px;
    border-radius: var(--radius);
    font-size: 14px;
    margin-bottom: 20px;
    display: flex;
    align-items: flex-start;
    gap: 10px;
    line-height: 1.5;
  }

  .alert-info {
    background: rgba(91,110,245,0.1);
    border: 1px solid rgba(91,110,245,0.3);
    color: #a5b4fc;
  }

  .alert-success {
    background: rgba(52,211,153,0.1);
    border: 1px solid rgba(52,211,153,0.3);
    color: var(--success);
  }

  .alert-error {
    background: rgba(248,113,113,0.1);
    border: 1px solid rgba(248,113,113,0.3);
    color: var(--error);
  }

  .alert-warning {
    background: rgba(251,191,36,0.1);
    border: 1px solid rgba(251,191,36,0.3);
    color: var(--warning);
  }

  /* Test connection button area */
  .connection-test {
    margin-top: 20px;
  }

  #test-result {
    margin-top: 12px;
    display: none;
  }

  /* Logo upload */
  .upload-zone {
    border: 2px dashed var(--border);
    border-radius: var(--radius);
    padding: 32px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
  }

  .upload-zone:hover, .upload-zone.dragover {
    border-color: var(--accent);
    background: rgba(91,110,245,0.05);
  }

  .upload-zone input[type="file"] {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
  }

  .upload-zone .upload-icon { font-size: 32px; margin-bottom: 8px; }
  .upload-zone p { color: var(--text-muted); font-size: 14px; }
  .upload-zone strong { color: var(--accent); }

  #logo-preview {
    display: none;
    margin-top: 16px;
    text-align: center;
  }

  #logo-preview img {
    max-height: 80px;
    max-width: 200px;
    border-radius: 8px;
    border: 1px solid var(--border);
  }

  /* User list in step 6 */
  .user-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 16px;
    max-height: 220px;
    overflow-y: auto;
  }

  .user-item {
    display: flex;
    align-items: center;
    gap: 12px;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 12px 16px;
  }

  .user-avatar {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 14px;
    flex-shrink: 0;
  }

  .user-name { flex: 1; font-weight: 500; }

  .user-remove {
    background: none;
    border: none;
    color: var(--error);
    cursor: pointer;
    font-size: 18px;
    padding: 4px;
    line-height: 1;
    opacity: 0.6;
    transition: opacity 0.2s;
  }

  .user-remove:hover { opacity: 1; }

  .add-user-row {
    display: flex;
    gap: 10px;
  }

  .add-user-row input {
    flex: 1;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 11px 16px;
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 14px;
    outline: none;
  }

  .add-user-row input:focus {
    border-color: var(--accent);
  }

  /* Step complete */
  .complete-icon {
    text-align: center;
    font-size: 64px;
    margin-bottom: 20px;
    animation: popIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  }

  @keyframes popIn {
    from { transform: scale(0); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
  }

  .complete-title {
    font-family: 'Syne', sans-serif;
    font-size: 26px;
    font-weight: 800;
    text-align: center;
    margin-bottom: 10px;
    background: linear-gradient(135deg, var(--success), #6ee7b7);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .complete-desc {
    text-align: center;
    color: var(--text-muted);
    margin-bottom: 28px;
    line-height: 1.6;
  }

  /* Password strength */
  .password-strength {
    margin-top: 8px;
    height: 4px;
    border-radius: 2px;
    background: var(--border);
    overflow: hidden;
  }

  .password-strength-bar {
    height: 100%;
    border-radius: 2px;
    transition: width 0.3s, background 0.3s;
    width: 0;
  }

  .hint { font-size: 12px; color: var(--text-muted); margin-top: 6px; }

  /* Spinner */
  .spinner {
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.6s linear infinite;
    display: inline-block;
  }

  @keyframes spin { to { transform: rotate(360deg); } }

  /* Color picker row */
  .color-swatches {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 8px;
  }

  .color-swatch {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    cursor: pointer;
    border: 2px solid transparent;
    transition: transform 0.15s, border-color 0.15s;
  }

  .color-swatch:hover { transform: scale(1.15); }
  .color-swatch.selected { border-color: white; }

  @media (max-width: 500px) {
    .setup-card { padding: 24px 20px; }
    .form-row { grid-template-columns: 1fr; }
    .steps-nav { gap: 0; }
    .step-line { max-width: 30px; }
  }
</style>
</head>
<body>

<div class="setup-container">
  <div class="setup-header">
    <div class="logo-mark">
      <div class="logo-icon">🌉</div>
      <div class="logo-text">DrawBridge Canvas</div>
    </div>
    <p>Welcome! Let's get your whiteboard platform set up.</p>
  </div>

  <!-- Step Progress -->
  <div class="steps-nav" id="steps-nav">
    <div class="step-dot active" data-step="1"><div class="dot">1</div><div class="label">Database</div></div>
    <div class="step-line" id="line-1"></div>
    <div class="step-dot" data-step="2"><div class="dot">2</div><div class="label">Admin</div></div>
    <div class="step-line" id="line-2"></div>
    <div class="step-dot" data-step="3"><div class="dot">3</div><div class="label">Branding</div></div>
    <div class="step-line" id="line-3"></div>
    <div class="step-dot" data-step="4"><div class="dot">4</div><div class="label">Users</div></div>
    <div class="step-line" id="line-4"></div>
    <div class="step-dot" data-step="5"><div class="dot">✓</div><div class="label">Done!</div></div>
  </div>

  <div class="setup-card">

    <!-- Step 1: Database -->
    <div class="step-panel active" id="panel-1">
      <div class="step-title">🗄️ Database Connection</div>
      <div class="step-desc">
        First, create an empty MySQL database and user in your cPanel, then enter the details below. 
        <br><br>
        <strong>In cPanel:</strong> Go to <em>MySQL Databases</em> → Create a new database → Create a new user → Add the user to the database with <em>All Privileges</em>.
      </div>

      <div class="alert alert-info">
        💡 Your database credentials can usually be found in your cPanel under <strong>MySQL Databases</strong>. The hostname is typically <strong>localhost</strong>.
      </div>

      <div class="form-group">
        <label>MySQL Hostname</label>
        <input type="text" id="db_host" value="localhost" placeholder="localhost">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Database Name</label>
          <input type="text" id="db_name" placeholder="mydb_drawbridge">
        </div>
        <div class="form-group">
          <label>Database User</label>
          <input type="text" id="db_user" placeholder="mydb_user">
        </div>
      </div>
      <div class="form-group">
        <label>Database Password</label>
        <input type="password" id="db_pass" placeholder="••••••••••••">
      </div>

      <div class="connection-test">
        <button class="btn btn-secondary" onclick="testConnection()" id="test-btn">
          🔌 Test Connection
        </button>
        <div id="test-result"></div>
      </div>

      <div class="btn-actions">
        <div></div>
        <button class="btn btn-primary" onclick="nextStep(1)" id="step1-next" disabled>
          Initialize Database →
        </button>
      </div>
    </div>

    <!-- Step 2: Admin Account -->
    <div class="step-panel" id="panel-2">
      <div class="step-title">👑 Create Admin Account</div>
      <div class="step-desc">
        This will be your master admin account. Keep these credentials safe — the admin has full control over all users and boards.
      </div>

      <div class="form-group">
        <label>Admin Username</label>
        <input type="text" id="admin_user" placeholder="admin" autocomplete="off">
      </div>
      <div class="form-group">
        <label>Admin Password</label>
        <input type="password" id="admin_pass" placeholder="Choose a strong password" oninput="checkPasswordStrength(this.value)">
        <div class="password-strength"><div class="password-strength-bar" id="strength-bar"></div></div>
        <div class="hint" id="strength-hint">Enter a password</div>
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" id="admin_pass2" placeholder="Repeat password">
      </div>

      <div class="btn-actions">
        <button class="btn btn-ghost" onclick="prevStep(2)">← Back</button>
        <button class="btn btn-primary" onclick="nextStep(2)">Continue →</button>
      </div>
    </div>

    <!-- Step 3: Branding -->
    <div class="step-panel" id="panel-3">
      <div class="step-title">🎨 Branding & Identity</div>
      <div class="step-desc">
        Customise the name and logo that users will see on the login screen. You can always change these later in Admin settings.
      </div>

      <div class="form-group">
        <label>App / Canvas Name</label>
        <input type="text" id="app_name" value="DrawBridge Canvas" placeholder="My Whiteboard">
      </div>

      <div class="form-group">
        <label>Logo (optional)</label>
        <div class="upload-zone" id="logo-zone">
          <input type="file" id="logo_file" accept="image/png,image/jpeg,image/gif,image/webp,image/svg+xml" onchange="previewLogo(this)">
          <div class="upload-icon">🖼️</div>
          <p><strong>Click to upload</strong> or drag & drop</p>
          <p>PNG, JPG, SVG up to 5MB</p>
        </div>
        <div id="logo-preview">
          <img id="logo-preview-img" src="" alt="Logo preview">
          <br><button class="btn btn-ghost" onclick="clearLogo()" style="margin-top:8px;font-size:13px;">✕ Remove</button>
        </div>
      </div>

      <div class="btn-actions">
        <button class="btn btn-ghost" onclick="prevStep(3)">← Back</button>
        <button class="btn btn-primary" onclick="nextStep(3)">Continue →</button>
      </div>
    </div>

    <!-- Step 4: Create Users -->
    <div class="step-panel" id="panel-4">
      <div class="step-title">👥 Create Users</div>
      <div class="step-desc">
        Add your initial users below. Each user gets their own personal canvas. You can always add more from the Admin panel later.
      </div>

      <div class="user-list" id="user-list"></div>

      <div class="add-user-row">
        <input type="text" id="new_username" placeholder="Username" onkeydown="if(event.key==='Enter') addUser()">
        <input type="password" id="new_userpass" placeholder="Password" onkeydown="if(event.key==='Enter') addUser()">
        <button class="btn btn-secondary" onclick="addUser()">+ Add</button>
      </div>

      <div id="user-error" class="alert alert-error" style="display:none;margin-top:12px;"></div>

      <div class="btn-actions">
        <button class="btn btn-ghost" onclick="prevStep(4)">← Back</button>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-ghost" onclick="finishSetup(true)">Skip for now</button>
          <button class="btn btn-primary" onclick="finishSetup(false)">Finish Setup →</button>
        </div>
      </div>
    </div>

    <!-- Step 5: Done -->
    <div class="step-panel" id="panel-5">
      <div class="complete-icon">🎉</div>
      <div class="complete-title">You're all set!</div>
      <div class="complete-desc">
        DrawBridge Canvas is ready to use. Your admin account has been created and your database is initialized.
        <br><br>
        Log in with your admin credentials to start managing your whiteboard platform.
      </div>
      <button class="btn btn-primary btn-full" onclick="window.location.href='../auth/login.php'" style="font-size:16px;padding:14px;">
        🌉 Go to Login →
      </button>
    </div>

  </div><!-- /.setup-card -->
</div>

<script>
let currentStep = 1;
let connectionTested = false;
let pendingUsers = [];
let logoDataUrl = null;

// ─── Navigation ───────────────────────────────────────
function setStep(n) {
  document.querySelectorAll('.step-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.step-dot').forEach(d => {
    const s = parseInt(d.dataset.step);
    d.classList.remove('active','done');
    if (s === n) d.classList.add('active');
    if (s < n) d.classList.add('done');
  });
  for (let i = 1; i <= 4; i++) {
    const line = document.getElementById('line-' + i);
    if (line) line.classList.toggle('done', i < n);
  }
  document.getElementById('panel-' + n).classList.add('active');
  currentStep = n;
}

function prevStep(from) { setStep(from - 1); }

async function nextStep(from) {
  if (from === 1) return await initDatabase();
  if (from === 2) return validateAdmin();
  if (from === 3) return saveBranding();
  setStep(from + 1);
}

// ─── Step 1: Test & Init Database ─────────────────────
async function testConnection() {
  const btn = document.getElementById('test-btn');
  const result = document.getElementById('test-result');
  btn.innerHTML = '<span class="spinner"></span> Testing...';
  btn.disabled = true;
  result.style.display = 'none';

  const data = {
    host: document.getElementById('db_host').value.trim(),
    name: document.getElementById('db_name').value.trim(),
    user: document.getElementById('db_user').value.trim(),
    pass: document.getElementById('db_pass').value,
    action: 'test'
  };

  try {
    const res = await fetch('setup_ajax.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    const json = await res.json();
    result.style.display = 'flex';

    if (json.success) {
      result.className = 'alert alert-success';
      result.textContent = '✅ Connection successful! Ready to initialize.';
      connectionTested = true;
      document.getElementById('step1-next').disabled = false;
    } else {
      result.className = 'alert alert-error';
      result.textContent = '❌ ' + (json.error || 'Connection failed. Check your credentials.');
      connectionTested = false;
      document.getElementById('step1-next').disabled = true;
    }
  } catch(e) {
    result.style.display = 'flex';
    result.className = 'alert alert-error';
    result.textContent = '❌ Network error. Please try again.';
  }

  btn.innerHTML = '🔌 Test Connection';
  btn.disabled = false;
}

async function initDatabase() {
  if (!connectionTested) {
    alert('Please test your database connection first.');
    return;
  }

  const btn = document.getElementById('step1-next');
  btn.innerHTML = '<span class="spinner"></span> Initializing...';
  btn.disabled = true;

  const data = {
    host: document.getElementById('db_host').value.trim(),
    name: document.getElementById('db_name').value.trim(),
    user: document.getElementById('db_user').value.trim(),
    pass: document.getElementById('db_pass').value,
    action: 'init'
  };

  try {
    const res = await fetch('setup_ajax.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    const json = await res.json();

    if (json.success) {
      setStep(2);
    } else {
      alert('Database initialization failed: ' + (json.error || 'Unknown error'));
      btn.innerHTML = 'Initialize Database →';
      btn.disabled = false;
    }
  } catch(e) {
    alert('Network error during initialization.');
    btn.innerHTML = 'Initialize Database →';
    btn.disabled = false;
  }
}

// ─── Step 2: Admin Validation ──────────────────────────
function checkPasswordStrength(pw) {
  const bar = document.getElementById('strength-bar');
  const hint = document.getElementById('strength-hint');
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  const levels = [
    {w:'0%', bg:'transparent', text:'Enter a password'},
    {w:'20%', bg:'#f87171', text:'Very weak'},
    {w:'40%', bg:'#fb923c', text:'Weak'},
    {w:'60%', bg:'#fbbf24', text:'Fair'},
    {w:'80%', bg:'#34d399', text:'Strong'},
    {w:'100%', bg:'#10b981', text:'Very strong'},
  ];
  const l = levels[score];
  bar.style.width = l.w;
  bar.style.background = l.bg;
  hint.textContent = l.text;
  hint.style.color = l.bg;
}

async function validateAdmin() {
  const user = document.getElementById('admin_user').value.trim();
  const pass = document.getElementById('admin_pass').value;
  const pass2 = document.getElementById('admin_pass2').value;

  if (!user || user.length < 3) return alert('Username must be at least 3 characters.');
  if (pass.length < 6) return alert('Password must be at least 6 characters.');
  if (pass !== pass2) return alert('Passwords do not match.');

  // Save admin details temporarily and move to next step
  window._adminUser = user;
  window._adminPass = pass;
  setStep(3);
}

// ─── Step 3: Branding ─────────────────────────────────
function previewLogo(input) {
  if (!input.files || !input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    logoDataUrl = e.target.result;
    document.getElementById('logo-preview-img').src = logoDataUrl;
    document.getElementById('logo-preview').style.display = 'block';
    document.getElementById('logo-zone').style.display = 'none';
  };
  reader.readAsDataURL(input.files[0]);
}

function clearLogo() {
  logoDataUrl = null;
  document.getElementById('logo_file').value = '';
  document.getElementById('logo-preview').style.display = 'none';
  document.getElementById('logo-zone').style.display = 'block';
}

async function saveBranding() {
  const appName = document.getElementById('app_name').value.trim() || 'DrawBridge Canvas';
  window._appName = appName;
  window._logoData = logoDataUrl;
  setStep(4);
}

// ─── Step 4: Users ─────────────────────────────────────
function addUser() {
  const nameInput = document.getElementById('new_username');
  const passInput = document.getElementById('new_userpass');
  const errDiv = document.getElementById('user-error');
  const name = nameInput.value.trim();
  const pass = passInput.value;

  errDiv.style.display = 'none';

  if (!name || name.length < 2) { showUserError('Username must be at least 2 characters.'); return; }
  if (!pass || pass.length < 4) { showUserError('Password must be at least 4 characters.'); return; }
  if (pendingUsers.find(u => u.name === name)) { showUserError('That username already exists.'); return; }
  if (name === (window._adminUser || 'admin')) { showUserError('Username conflicts with admin account.'); return; }

  pendingUsers.push({ name, pass });
  nameInput.value = '';
  passInput.value = '';
  nameInput.focus();
  renderUserList();
}

function removeUser(name) {
  pendingUsers = pendingUsers.filter(u => u.name !== name);
  renderUserList();
}

function showUserError(msg) {
  const e = document.getElementById('user-error');
  e.textContent = '⚠️ ' + msg;
  e.style.display = 'flex';
}

function renderUserList() {
  const list = document.getElementById('user-list');
  if (pendingUsers.length === 0) {
    list.innerHTML = '<div style="color:var(--text-muted);font-size:13px;padding:8px 0;">No users added yet. You can add them now or later from the admin panel.</div>';
    return;
  }
  list.innerHTML = pendingUsers.map(u => `
    <div class="user-item">
      <div class="user-avatar">${u.name[0].toUpperCase()}</div>
      <div class="user-name">${u.name}</div>
      <button class="user-remove" onclick="removeUser('${u.name}')" title="Remove">✕</button>
    </div>
  `).join('');
}

renderUserList();

// ─── Finish Setup ──────────────────────────────────────
async function finishSetup(skip) {
  const btn = event.target;
  btn.innerHTML = '<span class="spinner"></span> Saving...';
  btn.disabled = true;

  const payload = {
    action: 'finish',
    admin_user: window._adminUser,
    admin_pass: window._adminPass,
    app_name: window._appName,
    logo: window._logoData || null,
    users: skip ? [] : pendingUsers
  };

  try {
    const res = await fetch('setup_ajax.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const json = await res.json();

    if (json.success) {
      setStep(5);
    } else {
      alert('Setup failed: ' + (json.error || 'Unknown error'));
      btn.innerHTML = skip ? 'Skip for now' : 'Finish Setup →';
      btn.disabled = false;
    }
  } catch(e) {
    alert('Network error during setup.');
    btn.innerHTML = skip ? 'Skip for now' : 'Finish Setup →';
    btn.disabled = false;
  }
}

// Drag and drop for logo
const logoZone = document.getElementById('logo-zone');
logoZone.addEventListener('dragover', e => { e.preventDefault(); logoZone.classList.add('dragover'); });
logoZone.addEventListener('dragleave', () => logoZone.classList.remove('dragover'));
logoZone.addEventListener('drop', e => {
  e.preventDefault();
  logoZone.classList.remove('dragover');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) {
    const dt = new DataTransfer();
    dt.items.add(file);
    document.getElementById('logo_file').files = dt.files;
    previewLogo(document.getElementById('logo_file'));
  }
});
</script>
</body>
</html>
