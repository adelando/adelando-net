<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel — DrawBridge Canvas</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0a0a0f;
  --surface: #13131a;
  --surface2: #1c1c28;
  --border: #2a2a3a;
  --accent: #5b6ef5;
  --accent2: #a78bfa;
  --success: #34d399;
  --error: #f87171;
  --warning: #fbbf24;
  --text: #e8e8f0;
  --text-muted: #7878a0;
  --sidebar: 220px;
  --radius: 10px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; }

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  display: flex;
  min-height: 100vh;
}

/* ── Sidebar ────────────────────────────────────────── */
#sidebar {
  width: var(--sidebar);
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  padding: 20px 0;
  flex-shrink: 0;
  position: sticky;
  top: 0;
  height: 100vh;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 20px 20px;
  border-bottom: 1px solid var(--border);
  margin-bottom: 16px;
  text-decoration: none;
}
.sidebar-logo span {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 14px;
  color: var(--text);
}

.nav-section {
  padding: 0 12px;
  margin-bottom: 8px;
}
.nav-section-label {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-muted);
  padding: 8px 8px 4px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: var(--radius);
  cursor: pointer;
  font-size: 14px;
  color: var(--text-muted);
  transition: all 0.15s;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  text-decoration: none;
}
.nav-item:hover { background: var(--surface2); color: var(--text); }
.nav-item.active { background: rgba(91,110,245,0.15); color: var(--accent); }
.nav-item .icon { font-size: 16px; width: 20px; text-align: center; }

.sidebar-footer {
  margin-top: auto;
  padding: 16px 12px 0;
  border-top: 1px solid var(--border);
}

/* ── Main ────────────────────────────────────────────── */
#main {
  flex: 1;
  overflow-y: auto;
  padding: 32px;
}

.page-header {
  margin-bottom: 28px;
}
.page-title {
  font-family: 'Syne', sans-serif;
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 4px;
}
.page-desc { color: var(--text-muted); font-size: 14px; }

/* ── Cards ───────────────────────────────────────────── */
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 20px;
}
.card-title {
  font-family: 'Syne', sans-serif;
  font-size: 15px;
  font-weight: 700;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}

.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 20px;
}
.stat-value {
  font-family: 'Syne', sans-serif;
  font-size: 32px;
  font-weight: 800;
  background: linear-gradient(135deg, var(--text), var(--accent2));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.stat-label { font-size: 13px; color: var(--text-muted); margin-top: 4px; }

/* ── Table ───────────────────────────────────────────── */
.table-wrap { overflow-x: auto; }

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}

th {
  text-align: left;
  padding: 10px 14px;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-muted);
  font-weight: 500;
  border-bottom: 1px solid var(--border);
}

td {
  padding: 12px 14px;
  border-bottom: 1px solid rgba(42,42,58,0.5);
  vertical-align: middle;
}

tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,0.02); }

.user-avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--accent);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 700;
  margin-right: 8px;
  vertical-align: middle;
}

.badge {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 600;
}
.badge-admin { background: rgba(167,139,250,0.2); color: var(--accent2); }
.badge-user  { background: rgba(91,110,245,0.15); color: #93c5fd; }
.badge-active { background: rgba(52,211,153,0.15); color: var(--success); }
.badge-inactive { background: rgba(248,113,113,0.15); color: var(--error); }

/* ── Buttons ─────────────────────────────────────────── */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 14px;
  border-radius: 8px;
  font-family: 'DM Sans', sans-serif;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  border: none;
  transition: all 0.15s;
}
.btn-primary { background: var(--accent); color: white; }
.btn-primary:hover { opacity: 0.85; }
.btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border); }
.btn-secondary:hover { background: var(--border); }
.btn-danger { background: rgba(248,113,113,0.15); color: var(--error); border: 1px solid rgba(248,113,113,0.2); }
.btn-danger:hover { background: rgba(248,113,113,0.25); }
.btn-sm { padding: 5px 10px; font-size: 12px; }
.btn-ghost { background: none; color: var(--text-muted); }
.btn-ghost:hover { color: var(--text); }

/* ── Form ────────────────────────────────────────────── */
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 12px; font-weight: 500; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 6px; }
.form-group input[type="text"], .form-group input[type="password"] {
  width: 100%;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 9px 14px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  outline: none;
}
.form-group input:focus { border-color: var(--accent); }

/* ── Modals ──────────────────────────────────────────── */
.modal-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.7);
  z-index: 1000; display: flex; align-items: center; justify-content: center;
  backdrop-filter: blur(4px); opacity: 0; pointer-events: none; transition: opacity 0.2s;
}
.modal-overlay.open { opacity: 1; pointer-events: all; }
.modal {
  background: var(--surface); border: 1px solid var(--border); border-radius: 20px;
  padding: 28px; width: 100%; max-width: 460px; margin: 20px;
  box-shadow: 0 32px 80px rgba(0,0,0,0.6);
  transform: scale(0.95); transition: transform 0.2s;
}
.modal-overlay.open .modal { transform: scale(1); }
.modal h2 { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 700; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
.modal-close { margin-left: auto; background: none; border: none; color: var(--text-muted); font-size: 20px; cursor: pointer; }
.modal-close:hover { color: var(--text); }
.modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }

/* ── Alert ───────────────────────────────────────────── */
.alert { padding: 12px 16px; border-radius: var(--radius); font-size: 13px; margin-bottom: 16px; }
.alert-success { background: rgba(52,211,153,0.1); border: 1px solid rgba(52,211,153,0.3); color: var(--success); }
.alert-error { background: rgba(248,113,113,0.1); border: 1px solid rgba(248,113,113,0.3); color: var(--error); }

/* ── Tab panels ──────────────────────────────────────── */
.tab-panel { display: none; }
.tab-panel.active { display: block; }

/* ── Thumbnail preview ───────────────────────────────── */
.canvas-thumb {
  width: 80px;
  height: 50px;
  border-radius: 6px;
  object-fit: cover;
  border: 1px solid var(--border);
  background: var(--surface2);
}

@media (max-width: 768px) {
  #sidebar { display: none; }
  #main { padding: 20px; }
  .form-row { grid-template-columns: 1fr; }
}
</style>
</head>
<body>
<?php
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';
dbc_require_admin();
$user = dbc_current_user();
$db   = dbc_get_db();
$app_name = dbc_get_setting('app_name', APP_NAME);
$app_logo = dbc_get_setting('app_logo', '');

// Stats
$stats = [];
$stats['users']   = $db->query("SELECT COUNT(*) FROM dbc_users")->fetchColumn();
$stats['canvases'] = $db->query("SELECT COUNT(*) FROM dbc_canvases WHERE is_active=1")->fetchColumn();
$stats['collab']  = $db->query("SELECT COUNT(*) FROM dbc_canvases WHERE type='collaborative' AND is_active=1")->fetchColumn();
$stats['active']  = $db->query("SELECT COUNT(*) FROM dbc_active_sessions WHERE last_seen > DATE_SUB(NOW(), INTERVAL 5 MINUTE)")->fetchColumn();

// Users
$users = $db->query("SELECT u.*, (SELECT COUNT(*) FROM dbc_canvases c WHERE c.owner_id=u.id) as canvas_count FROM dbc_users u ORDER BY u.id ASC")->fetchAll();

// Canvases
$canvases = $db->query("
    SELECT c.*, u.username as owner_name
    FROM dbc_canvases c
    JOIN dbc_users u ON u.id = c.owner_id
    WHERE c.is_active = 1
    ORDER BY c.updated_at DESC
")->fetchAll();

$tab = $_GET['tab'] ?? 'dashboard';
?>

<!-- Sidebar -->
<div id="sidebar">
  <a href="index.php" class="sidebar-logo">
    🌉 <span>Admin Panel</span>
  </a>

  <div class="nav-section">
    <div class="nav-section-label">Overview</div>
    <button class="nav-item <?= $tab === 'dashboard' ? 'active' : '' ?>" onclick="showTab('dashboard')">
      <span class="icon">📊</span> Dashboard
    </button>
  </div>

  <div class="nav-section">
    <div class="nav-section-label">Management</div>
    <button class="nav-item <?= $tab === 'users' ? 'active' : '' ?>" onclick="showTab('users')">
      <span class="icon">👥</span> Users
    </button>
    <button class="nav-item <?= $tab === 'canvases' ? 'active' : '' ?>" onclick="showTab('canvases')">
      <span class="icon">🖼️</span> Canvases
    </button>
  </div>

  <div class="nav-section">
    <div class="nav-section-label">System</div>
    <button class="nav-item <?= $tab === 'settings' ? 'active' : '' ?>" onclick="showTab('settings')">
      <span class="icon">⚙️</span> App Settings
    </button>
    <button class="nav-item <?= $tab === 'database' ? 'active' : '' ?>" onclick="showTab('database')">
      <span class="icon">🗄️</span> Database
    </button>
  </div>

  <div class="sidebar-footer">
    <a href="../canvas/index.php" class="nav-item">
      <span class="icon">🎨</span> My Canvas
    </a>
    <a href="../auth/logout.php" class="nav-item">
      <span class="icon">🚪</span> Logout
    </a>
  </div>
</div>

<!-- Main -->
<div id="main">

  <!-- Dashboard -->
  <div class="tab-panel <?= $tab === 'dashboard' ? 'active' : '' ?>" id="tab-dashboard">
    <div class="page-header">
      <div class="page-title">📊 Dashboard</div>
      <div class="page-desc">Welcome back, <?= htmlspecialchars($user['username']) ?>. Here's an overview of DrawBridge Canvas.</div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-value"><?= $stats['users'] ?></div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-card">
        <div class="stat-value"><?= $stats['canvases'] ?></div>
        <div class="stat-label">Active Canvases</div>
      </div>
      <div class="stat-card">
        <div class="stat-value"><?= $stats['collab'] ?></div>
        <div class="stat-label">Collab Canvases</div>
      </div>
      <div class="stat-card">
        <div class="stat-value"><?= $stats['active'] ?></div>
        <div class="stat-label">Active Now</div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">⚡ Quick Actions</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button class="btn btn-primary" onclick="showTab('users');openModal('addUserModal')">➕ Add User</button>
        <button class="btn btn-secondary" onclick="showTab('canvases')">🖼️ Manage Canvases</button>
        <button class="btn btn-secondary" onclick="showTab('settings')">⚙️ App Settings</button>
      </div>
    </div>
  </div>

  <!-- Users -->
  <div class="tab-panel <?= $tab === 'users' ? 'active' : '' ?>" id="tab-users">
    <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
      <div>
        <div class="page-title">👥 User Management</div>
        <div class="page-desc">Manage all users, reset passwords, and control access.</div>
      </div>
      <button class="btn btn-primary" onclick="openModal('addUserModal')">➕ Add User</button>
    </div>

    <div id="user-alert"></div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>User</th>
              <th>Role</th>
              <th>Canvases</th>
              <th>Last Login</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $u): ?>
            <tr id="user-row-<?= $u['id'] ?>">
              <td>
                <span class="user-avatar" style="background:<?= htmlspecialchars($u['avatar_color']) ?>"><?= strtoupper($u['username'][0]) ?></span>
                <?= htmlspecialchars($u['username']) ?>
              </td>
              <td><span class="badge badge-<?= $u['role'] ?>"><?= ucfirst($u['role']) ?></span></td>
              <td><?= (int)$u['canvas_count'] ?></td>
              <td><?= $u['last_login'] ? date('d M Y', strtotime($u['last_login'])) : 'Never' ?></td>
              <td><span class="badge badge-<?= $u['is_active'] ? 'active' : 'inactive' ?>"><?= $u['is_active'] ? 'Active' : 'Disabled' ?></span></td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  <button class="btn btn-secondary btn-sm" onclick="openRenameUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">✏️ Rename</button>
                  <button class="btn btn-secondary btn-sm" onclick="openResetPw(<?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">🔑 Reset PW</button>
                  <button class="btn btn-secondary btn-sm" onclick="viewUserCanvases(<?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">🖼️ Boards</button>
                  <?php if ($u['id'] != $user['id'] && $u['role'] !== 'admin'): ?>
                  <button class="btn btn-danger btn-sm" onclick="toggleUserActive(<?= $u['id'] ?>, <?= $u['is_active'] ?>)"><?= $u['is_active'] ? '🚫 Disable' : '✅ Enable' ?></button>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Canvases -->
  <div class="tab-panel <?= $tab === 'canvases' ? 'active' : '' ?>" id="tab-canvases">
    <div class="page-header">
      <div class="page-title">🖼️ Canvas Management</div>
      <div class="page-desc">View and manage all boards. Admin can view any canvas.</div>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Canvas</th>
              <th>Owner</th>
              <th>Type</th>
              <th>Last Updated</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($canvases as $c): ?>
            <tr id="canvas-row-<?= $c['id'] ?>">
              <td>
                <?php if ($c['thumbnail']): ?>
                  <img src="<?= htmlspecialchars($c['thumbnail']) ?>" class="canvas-thumb" style="margin-right:8px;vertical-align:middle;">
                <?php endif; ?>
                <?= htmlspecialchars($c['name']) ?>
              </td>
              <td><?= htmlspecialchars($c['owner_name']) ?></td>
              <td>
                <?php if ($c['type'] === 'collaborative'): ?>
                  <span class="badge" style="background:rgba(52,211,153,0.15);color:var(--success)">👥 Collab</span>
                <?php else: ?>
                  <span class="badge badge-user">🔒 Personal</span>
                <?php endif; ?>
              </td>
              <td><?= date('d M Y H:i', strtotime($c['updated_at'])) ?></td>
              <td>
                <div style="display:flex;gap:6px;">
                  <a href="../canvas/index.php?canvas=<?= $c['id'] ?>" class="btn btn-secondary btn-sm" target="_blank">👁️ View</a>
                  <button class="btn btn-danger btn-sm" onclick="deleteCanvas(<?= $c['id'] ?>, '<?= htmlspecialchars($c['name']) ?>')">🗑️ Delete</button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- App Settings -->
  <div class="tab-panel <?= $tab === 'settings' ? 'active' : '' ?>" id="tab-settings">
    <div class="page-header">
      <div class="page-title">⚙️ App Settings</div>
      <div class="page-desc">Update branding and application settings.</div>
    </div>

    <div class="card">
      <div class="card-title">🎨 Branding</div>
      <div id="settings-alert"></div>
      <div class="form-group">
        <label>App Name</label>
        <input type="text" id="setting-app-name" value="<?= htmlspecialchars($app_name) ?>">
      </div>
      <div class="form-group">
        <label>Logo</label>
        <?php if ($app_logo && file_exists(dirname(__FILE__, 2) . '/' . $app_logo)): ?>
          <div style="margin-bottom:10px;">
            <img src="../<?= htmlspecialchars($app_logo) ?>" style="max-height:60px;border-radius:8px;border:1px solid var(--border);">
          </div>
        <?php endif; ?>
        <input type="file" id="setting-logo" accept="image/*" style="color:var(--text-muted);font-size:13px;">
      </div>
      <button class="btn btn-primary" onclick="saveAppSettings()">💾 Save Settings</button>
    </div>
  </div>

  <!-- Database -->
  <div class="tab-panel <?= $tab === 'database' ? 'active' : '' ?>" id="tab-database">
    <div class="page-header">
      <div class="page-title">🗄️ Database Settings</div>
      <div class="page-desc">View and update the database connection. Changes take effect immediately.</div>
    </div>

    <div class="card">
      <div class="card-title">Current Connection</div>
      <div id="db-alert"></div>
      <div class="form-group">
        <label>MySQL Host</label>
        <input type="text" id="db-host" value="<?= htmlspecialchars(DB_HOST) ?>">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Database Name</label>
          <input type="text" id="db-name" value="<?= htmlspecialchars(DB_NAME) ?>">
        </div>
        <div class="form-group">
          <label>Database User</label>
          <input type="text" id="db-user" value="<?= htmlspecialchars(DB_USER) ?>">
        </div>
      </div>
      <div class="form-group">
        <label>Database Password</label>
        <input type="password" id="db-pass" placeholder="Leave blank to keep current">
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button class="btn btn-secondary" onclick="testDbConnection()">🔌 Test Connection</button>
        <button class="btn btn-primary" onclick="saveDbSettings()">💾 Update Connection</button>
      </div>
      <div id="db-result" style="margin-top:12px;"></div>
    </div>
  </div>

</div><!-- /#main -->

<!-- ════ MODALS ════ -->

<!-- Add User -->
<div class="modal-overlay" id="addUserModal">
<div class="modal">
  <h2>➕ Add User <button class="modal-close" onclick="closeModal('addUserModal')">✕</button></h2>
  <div id="add-user-alert"></div>
  <div class="form-group"><label>Username</label><input type="text" id="new-user-name" placeholder="username"></div>
  <div class="form-group"><label>Password</label><input type="password" id="new-user-pass" placeholder="password"></div>
  <div class="form-group">
    <label>Role</label>
    <select id="new-user-role" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:9px 14px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:14px;outline:none;">
      <option value="user">User</option>
      <option value="admin">Admin</option>
    </select>
  </div>
  <div class="modal-actions">
    <button class="btn btn-secondary" onclick="closeModal('addUserModal')">Cancel</button>
    <button class="btn btn-primary" onclick="addUser()">Create User</button>
  </div>
</div>
</div>

<!-- Rename User -->
<div class="modal-overlay" id="renameUserModal">
<div class="modal">
  <h2>✏️ Rename User <button class="modal-close" onclick="closeModal('renameUserModal')">✕</button></h2>
  <input type="hidden" id="rename-user-id">
  <div class="form-group"><label>New Username</label><input type="text" id="rename-user-value" placeholder="New username"></div>
  <div class="modal-actions">
    <button class="btn btn-secondary" onclick="closeModal('renameUserModal')">Cancel</button>
    <button class="btn btn-primary" onclick="renameUser()">Rename</button>
  </div>
</div>
</div>

<!-- Reset Password -->
<div class="modal-overlay" id="resetPwModal">
<div class="modal">
  <h2>🔑 Reset Password <button class="modal-close" onclick="closeModal('resetPwModal')">✕</button></h2>
  <div id="reset-pw-label" style="color:var(--text-muted);font-size:13px;margin-bottom:14px;"></div>
  <input type="hidden" id="reset-pw-user-id">
  <div class="form-group"><label>New Password</label><input type="password" id="reset-pw-value" placeholder="New password (min 6)"></div>
  <div class="modal-actions">
    <button class="btn btn-secondary" onclick="closeModal('resetPwModal')">Cancel</button>
    <button class="btn btn-primary" onclick="resetPassword()">Reset Password</button>
  </div>
</div>
</div>

<!-- View User Canvases (quick view) -->
<div class="modal-overlay" id="userCanvasesModal">
<div class="modal" style="max-width:540px;">
  <h2>🖼️ <span id="user-canvases-title">User</span>'s Canvases <button class="modal-close" onclick="closeModal('userCanvasesModal')">✕</button></h2>
  <div id="user-canvases-list"></div>
</div>
</div>

<script>
const currentUserId = <?= (int)$user['id'] ?>;

// ─── Tab Navigation ───────────────────────────────────
function showTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  document.querySelector(`.nav-item[onclick="showTab('${name}')"]`)?.classList.add('active');
  history.replaceState(null, '', '?tab=' + name);
}

// ─── Modal Helpers ────────────────────────────────────
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
});

// ─── Alert Helpers ────────────────────────────────────
function showAlert(containerId, msg, type = 'error') {
  const el = document.getElementById(containerId);
  el.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  setTimeout(() => el.innerHTML = '', 4000);
}

// ─── Add User ─────────────────────────────────────────
async function addUser() {
  const name = document.getElementById('new-user-name').value.trim();
  const pass = document.getElementById('new-user-pass').value;
  const role = document.getElementById('new-user-role').value;

  if (!name || pass.length < 4) { showAlert('add-user-alert', 'Username and password (min 4) required.'); return; }

  const res = await adminFetch({ action: 'add_user', username: name, password: pass, role });
  if (res.success) {
    closeModal('addUserModal');
    showAlert('user-alert', '✅ User created! Refresh to see.', 'success');
    document.getElementById('new-user-name').value = '';
    document.getElementById('new-user-pass').value = '';
    setTimeout(() => location.reload(), 1200);
  } else {
    showAlert('add-user-alert', '❌ ' + (res.error || 'Failed'));
  }
}

// ─── Rename User ──────────────────────────────────────
function openRenameUser(id, current) {
  document.getElementById('rename-user-id').value = id;
  document.getElementById('rename-user-value').value = current;
  openModal('renameUserModal');
}

async function renameUser() {
  const id    = document.getElementById('rename-user-id').value;
  const value = document.getElementById('rename-user-value').value.trim();
  if (!value || value.length < 2) { alert('Username must be at least 2 characters'); return; }

  const res = await adminFetch({ action: 'rename_user', user_id: id, username: value });
  if (res.success) {
    closeModal('renameUserModal');
    showAlert('user-alert', '✅ User renamed!', 'success');
    setTimeout(() => location.reload(), 1000);
  } else {
    alert('Error: ' + (res.error || 'Failed'));
  }
}

// ─── Reset Password ───────────────────────────────────
function openResetPw(id, username) {
  document.getElementById('reset-pw-user-id').value = id;
  document.getElementById('reset-pw-label').textContent = 'Setting new password for: ' + username;
  document.getElementById('reset-pw-value').value = '';
  openModal('resetPwModal');
}

async function resetPassword() {
  const id   = document.getElementById('reset-pw-user-id').value;
  const pass = document.getElementById('reset-pw-value').value;
  if (pass.length < 6) { alert('Password must be at least 6 characters'); return; }

  const res = await adminFetch({ action: 'reset_password', user_id: id, password: pass });
  if (res.success) {
    closeModal('resetPwModal');
    showAlert('user-alert', '✅ Password reset!', 'success');
  } else {
    alert('Error: ' + (res.error || 'Failed'));
  }
}

// ─── Toggle User Active ───────────────────────────────
async function toggleUserActive(id, current) {
  if (!confirm((current ? 'Disable' : 'Enable') + ' this user?')) return;
  const res = await adminFetch({ action: 'toggle_user', user_id: id });
  if (res.success) {
    showAlert('user-alert', '✅ User updated!', 'success');
    setTimeout(() => location.reload(), 1000);
  } else {
    alert('Error: ' + (res.error || 'Failed'));
  }
}

// ─── View User Canvases ───────────────────────────────
async function viewUserCanvases(id, username) {
  document.getElementById('user-canvases-title').textContent = username;
  document.getElementById('user-canvases-list').innerHTML = 'Loading...';
  openModal('userCanvasesModal');

  const res = await adminFetch({ action: 'get_user_canvases', user_id: id });
  if (res.success && res.canvases) {
    if (!res.canvases.length) {
      document.getElementById('user-canvases-list').innerHTML = '<p style="color:var(--text-muted);font-size:13px;">No canvases.</p>';
    } else {
      document.getElementById('user-canvases-list').innerHTML = res.canvases.map(c => `
        <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border);">
          ${c.thumbnail ? `<img src="${c.thumbnail}" class="canvas-thumb">` : '<div class="canvas-thumb" style="display:inline-block;"></div>'}
          <div style="flex:1;">
            <div style="font-weight:500;font-size:14px;">${c.name}</div>
            <div style="font-size:12px;color:var(--text-muted);">${c.type}</div>
          </div>
          <a href="../canvas/index.php?canvas=${c.id}" class="btn btn-secondary btn-sm" target="_blank">👁️ View</a>
        </div>
      `).join('');
    }
  }
}

// ─── Delete Canvas ────────────────────────────────────
async function deleteCanvas(id, name) {
  if (!confirm(`Delete canvas "${name}"? This cannot be undone.`)) return;
  const res = await adminFetch({ action: 'delete_canvas', canvas_id: id });
  if (res.success) {
    document.getElementById('canvas-row-' + id)?.remove();
  } else {
    alert('Error: ' + (res.error || 'Failed'));
  }
}

// ─── App Settings ─────────────────────────────────────
async function saveAppSettings() {
  const name = document.getElementById('setting-app-name').value.trim();
  const logoFile = document.getElementById('setting-logo').files[0];

  let logoData = null;
  if (logoFile) {
    logoData = await fileToDataUrl(logoFile);
  }

  const res = await adminFetch({ action: 'save_app_settings', app_name: name, logo: logoData });
  if (res.success) {
    showAlert('settings-alert', '✅ Settings saved!', 'success');
  } else {
    showAlert('settings-alert', '❌ ' + (res.error || 'Failed'));
  }
}

// ─── Database Settings ────────────────────────────────
async function testDbConnection() {
  const result = document.getElementById('db-result');
  result.textContent = 'Testing...';

  const res = await adminFetch({
    action: 'test_db',
    host: document.getElementById('db-host').value.trim(),
    name: document.getElementById('db-name').value.trim(),
    user: document.getElementById('db-user').value.trim(),
    pass: document.getElementById('db-pass').value,
  });

  if (res.success) {
    result.innerHTML = '<span style="color:var(--success)">✅ Connection successful!</span>';
  } else {
    result.innerHTML = '<span style="color:var(--error)">❌ ' + (res.error || 'Failed') + '</span>';
  }
}

async function saveDbSettings() {
  if (!confirm('Update database connection? The app will use the new settings immediately.')) return;

  const res = await adminFetch({
    action: 'save_db',
    host: document.getElementById('db-host').value.trim(),
    name: document.getElementById('db-name').value.trim(),
    user: document.getElementById('db-user').value.trim(),
    pass: document.getElementById('db-pass').value,
  });

  const result = document.getElementById('db-result');
  if (res.success) {
    result.innerHTML = '<span style="color:var(--success)">✅ Database settings updated!</span>';
  } else {
    result.innerHTML = '<span style="color:var(--error)">❌ ' + (res.error || 'Failed') + '</span>';
  }
}

// ─── Helpers ─────────────────────────────────────────
async function adminFetch(payload) {
  try {
    const res = await fetch('../api/admin.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    return await res.json();
  } catch(e) {
    return { success: false, error: 'Network error' };
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = e => resolve(e.target.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}
</script>
</body>
</html>
