<?php
// DrawBridge Canvas - Bootstrap

// Find root config
$root = dirname(__FILE__, 2);
$config_file = $root . '/config.php';

if (!file_exists($config_file)) {
    die('Configuration file not found. Please run setup.');
}

require_once $config_file;

// If not installed, redirect to setup
if (!defined('DBC_INSTALLED') || !DBC_INSTALLED) {
    $current = $_SERVER['PHP_SELF'] ?? '';
    if (strpos($current, '/setup/') === false) {
        header('Location: /setup/index.php');
        exit;
    }
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
