<?php
// DrawBridge Canvas - Login
// ALL PHP logic must run before any HTML output
require_once dirname(__FILE__, 2) . '/includes/bootstrap.php';

// Helper: build absolute URL to a path relative to app root
function app_url($path) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME']; // e.g. /drawbridge/auth/login.php
    $app_root = rtrim(dirname(dirname($script)), '/'); // e.g. /drawbridge
    return $protocol . '://' . $host . $app_root . '/' . ltrim($path, '/');
}

// If already logged in, go straight to canvas
if (dbc_is_logged_in()) {
    header('Location: ' . app_url('canvas/index.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = dbc_get_db();
        $stmt = $db->prepare("SELECT * FROM dbc_users WHERE username = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$username]);
        $user_row = $stmt->fetch();

        if ($user_row && dbc_verify_password($password, $user_row['password'])) {
            dbc_login_user($user_row);
            header('Location: ' . app_url('canvas/index.php'));
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please enter your username and password.';
    }
}

$app_name = dbc_get_setting('app_name', APP_NAME);
$app_logo = dbc_get_setting('app_logo', '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($app_name) ?> — Login</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0a0f;
    --surface: #13131a;
    --border: #2a2a3a;
    --accent: #5b6ef5;
    --accent2: #a78bfa;
    --error: #f87171;
    --text: #e8e8f0;
    --text-muted: #7878a0;
    --radius: 14px;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background: 
      radial-gradient(ellipse 70% 60% at 15% 15%, rgba(91,110,245,0.15) 0%, transparent 60%),
      radial-gradient(ellipse 60% 50% at 85% 85%, rgba(167,139,250,0.1) 0%, transparent 60%);
    pointer-events: none;
  }

  .login-card {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 420px;
    margin: 20px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 24px;
    padding: 44px 40px;
    box-shadow: 0 32px 100px rgba(0,0,0,0.6);
  }

  .logo-area {
    text-align: center;
    margin-bottom: 36px;
  }

  .app-logo {
    max-height: 64px;
    max-width: 200px;
    margin-bottom: 16px;
    display: block;
    margin-left: auto;
    margin-right: auto;
  }

  .logo-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    margin: 0 auto 16px;
    box-shadow: 0 0 40px rgba(91,110,245,0.4);
  }

  .app-name {
    font-family: 'Syne', sans-serif;
    font-size: 20px;
    font-weight: 800;
    background: linear-gradient(135deg, #fff 0%, var(--accent2) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .login-title {
    font-family: 'Syne', sans-serif;
    font-size: 26px;
    font-weight: 700;
    margin-bottom: 6px;
  }

  .login-sub {
    color: var(--text-muted);
    font-size: 14px;
    margin-bottom: 32px;
  }

  .form-group {
    margin-bottom: 18px;
  }

  .form-group label {
    display: block;
    font-size: 12px;
    font-weight: 500;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 8px;
  }

  .input-wrap {
    position: relative;
  }

  .input-wrap .icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 16px;
    pointer-events: none;
  }

  .input-wrap input {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 13px 16px 13px 42px;
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 15px;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }

  .input-wrap input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(91,110,245,0.15);
  }

  .toggle-pass {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    font-size: 16px;
    color: var(--text-muted);
    padding: 4px;
    transition: color 0.2s;
  }
  .toggle-pass:hover { color: var(--text); }

  .error-box {
    background: rgba(248,113,113,0.1);
    border: 1px solid rgba(248,113,113,0.3);
    color: var(--error);
    border-radius: var(--radius);
    padding: 12px 16px;
    font-size: 14px;
    margin-bottom: 20px;
    display: none;
  }

  .btn-login {
    width: 100%;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    color: white;
    border: none;
    border-radius: var(--radius);
    padding: 14px;
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    margin-top: 8px;
    transition: all 0.2s;
    box-shadow: 0 4px 24px rgba(91,110,245,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }

  .btn-login:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 32px rgba(91,110,245,0.45);
  }

  .btn-login:active { transform: translateY(0); }
  .btn-login:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

  .footer-note {
    text-align: center;
    color: var(--text-muted);
    font-size: 12px;
    margin-top: 28px;
  }

  .spinner {
    width: 18px;
    height: 18px;
    border: 2px solid rgba(255,255,255,0.4);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.6s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  @media (max-width: 460px) {
    .login-card { padding: 32px 24px; }
  }
</style>
</head>
<body>
<?php
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = dbc_get_db();
        $stmt = $db->prepare("SELECT * FROM dbc_users WHERE username = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user_row && dbc_verify_password($password, $user_row['password'])) {
            dbc_login_user($user_row);
            header('Location: ' . app_url('canvas/index.php'));
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please enter your username and password.';
    }
}
?>

<div class="login-card">
  <div class="logo-area">
    <?php if ($app_logo && file_exists(dirname(__FILE__, 2) . '/' . $app_logo)): ?>
      <img src="<?= htmlspecialchars(app_url($app_logo)) ?>" alt="<?= htmlspecialchars($app_name) ?>" class="app-logo">
    <?php else: ?>
      <div class="logo-icon">🌉</div>
    <?php endif; ?>
    <div class="app-name"><?= htmlspecialchars($app_name) ?></div>
  </div>

  <div class="login-title">Welcome back</div>
  <div class="login-sub">Sign in to your whiteboard</div>

  <?php if ($error): ?>
    <div class="error-box" style="display:flex">⚠️ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label>Username</label>
      <div class="input-wrap">
        <span class="icon">👤</span>
        <input type="text" name="username" placeholder="Enter your username" required autofocus
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
      </div>
    </div>

    <div class="form-group">
      <label>Password</label>
      <div class="input-wrap">
        <span class="icon">🔒</span>
        <input type="password" name="password" id="pass-input" placeholder="Enter your password" required>
        <button type="button" class="toggle-pass" onclick="togglePass()" id="toggle-btn">👁️</button>
      </div>
    </div>

    <button type="submit" class="btn-login" id="login-btn">
      Sign In →
    </button>
  </form>

  <div class="footer-note">
    DrawBridge Canvas <?= defined('APP_VERSION') ? 'v' . APP_VERSION : '' ?>
  </div>
</div>

<script>
function togglePass() {
  const input = document.getElementById('pass-input');
  const btn   = document.getElementById('toggle-btn');
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = '🙈';
  } else {
    input.type = 'password';
    btn.textContent = '👁️';
  }
}
</script>
</body>
</html>
