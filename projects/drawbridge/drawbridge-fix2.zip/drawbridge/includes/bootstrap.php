<?php
// DrawBridge Canvas - Bootstrap

$root = dirname(__FILE__, 2);
$config_file = $root . '/config.php';

if (!file_exists($config_file)) {
    die('Configuration file not found. Please upload all DrawBridge Canvas files.');
}

require_once $config_file;

// Helper to build absolute URL - available very early
function dbc_abs_url($path) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $parts = explode('/', trim($script, '/'));
    array_pop($parts); // remove filename
    $known = ['auth','canvas','admin','api','setup','includes'];
    if (!empty($parts) && in_array(end($parts), $known)) array_pop($parts);
    $base = '/' . implode('/', array_filter($parts));
    $base = rtrim($base, '/');
    return $protocol . '://' . $host . $base . '/' . ltrim($path, '/');
}

// If not installed, redirect to setup (unless we're already there)
if (!defined('DBC_INSTALLED') || !DBC_INSTALLED) {
    $current = $_SERVER['PHP_SELF'] ?? '';
    if (strpos($current, '/setup/') === false) {
        header('Location: ' . dbc_abs_url('setup/index.php'));
        exit;
    }
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
